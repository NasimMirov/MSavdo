import express from 'express';
import { DatabaseSync } from 'node:sqlite';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import crypto from 'node:crypto';
import { GoogleGenAI } from '@google/genai';
import { analyzeSemantically, cleanProductTitle, translateVariantName } from './src/utils/semanticAi.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// ==========================================
// НАСТРОЙКА CORS
// ==========================================
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

app.use(express.json({ limit: '15mb' }));

// ==========================================
// ИНИЦИАЛИЗАЦИЯ GEMINI API (@google/genai)
// ==========================================
let aiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  aiClient = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// ==========================================
// БАЗА ДАННЫХ SQLITE (msavdo.db)
// ==========================================
const dbPath = path.join(__dirname, 'msavdo.db');
const db = new DatabaseSync(dbPath);

db.exec('PRAGMA foreign_keys = ON;');

// Миграция таблиц: categories, products, product_variants, admin_users, settings
db.exec(`
  CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    parent_id INTEGER,
    FOREIGN KEY (parent_id) REFERENCES categories (id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    original_link TEXT,
    category_id INTEGER,
    base_sku TEXT UNIQUE NOT NULL,
    status TEXT DEFAULT 'active',
    delivery_type TEXT DEFAULT 'order',
    main_image TEXT,
    images TEXT,
    video_url TEXT,
    youtube_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS product_variants (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL,
    color TEXT,
    size TEXT,
    price_cny REAL NOT NULL,
    price_tjs INTEGER NOT NULL,
    stock INTEGER DEFAULT 10,
    weight_kg REAL DEFAULT 0.5,
    variant_sku TEXT UNIQUE NOT NULL,
    image_url TEXT,
    FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS admin_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
`);

// Автоматическая миграция новых колонок для существующих БД
try {
  db.exec('ALTER TABLE products ADD COLUMN images TEXT;');
} catch (_) {}
try {
  db.exec('ALTER TABLE products ADD COLUMN video_url TEXT;');
} catch (_) {}
try {
  db.exec('ALTER TABLE products ADD COLUMN youtube_url TEXT;');
} catch (_) {}
try {
  db.exec("ALTER TABLE products ADD COLUMN delivery_type TEXT DEFAULT 'order';");
} catch (_) {}

// Гарантируем наличие 5 ключевых категорий платформы
const standardCategories = [
  'Мужская коллекция',
  'Женская коллекция',
  'Премиальная обувь',
  'Аудио и смарт-гаджеты',
  'Игрушки и хобби',
];
for (const catName of standardCategories) {
  const row = db.prepare('SELECT id FROM categories WHERE name = ?').get(catName);
  if (!row) {
    db.prepare('INSERT INTO categories (name, parent_id) VALUES (?, NULL)').run(catName);
  }
}

// Хранилище сессий администраторов в памяти
const activeAdminTokens = new Set<string>();

// Хеширование паролей
function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password + '_msavdo_salt').digest('hex');
}

// Настройки по умолчанию
function getSetting(key: string, defaultValue: string): string {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key) as { value: string } | undefined;
  return row ? row.value : defaultValue;
}

function setSetting(key: string, value: string): void {
  db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').run(key, value);
}

if (!db.prepare('SELECT value FROM settings WHERE key = ?').get('cny_tjs_rate')) {
  setSetting('cny_tjs_rate', '1.45');
}
if (!db.prepare('SELECT value FROM settings WHERE key = ?').get('delivery_per_kg_tjs')) {
  setSetting('delivery_per_kg_tjs', '30');
}
if (!db.prepare('SELECT value FROM settings WHERE key = ?').get('whatsapp_phone')) {
  setSetting('whatsapp_phone', '992444431');
}

// Создание супер-админа по умолчанию (admin / admin123)
const adminCount = (db.prepare('SELECT COUNT(*) as count FROM admin_users').get() as { count: number }).count;
if (adminCount === 0) {
  const defaultHash = hashPassword('admin123');
  db.prepare('INSERT INTO admin_users (username, password_hash) VALUES (?, ?)').run('admin', defaultHash);
  console.log('✓ Создан администратор по умолчанию: admin / admin123');
}

// ==========================================
// СТРОГАЯ ФИНАНСОВАЯ МАТЕМАТИКА (TJS)
// ==========================================
/**
 * Железная финансовая формула ценообразования M.Savdo:
 * - Курс юаня (берется из настроек, по умолчанию 1.45)
 * - Доставка: Фиксированно 30 сомони за 1 кг веса
 * - Дифференцированная наценка:
 *   * Дешевые товары (до ¥20 за вариант): Коэффициент 2.0 (100% наценка)
 *   * Средние товары (¥21 – ¥100 за вариант): Коэффициент 1.6 (60% наценка)
 *   * Дорогие товары (выше ¥101 за вариант): Коэффициент 1.3 (30% наценка)
 * Итоговая формула цены варианта в TJS:
 * TJS = round((Цена_Варианта_CNY * Курс * Коэффициент_Наценки) + (Вес_Варианта_кг * 30))
 * Пример: Куртка ¥135, вес 1кг -> round((135 * 1.45 * 1.3) + (1 * 30)) = round(254.47 + 30) = 284 TJS.
 */
function calculateVariantPriceTjs(priceCny: number, weightKg: number = 0.5): number {
  const rate = parseFloat(getSetting('cny_tjs_rate', '1.45')) || 1.45;
  const numCny = Number(priceCny) || 50;
  const numWeight = Number(weightKg) || 0.5;

  let markupMultiplier = 1.3;
  if (numCny <= 20) {
    markupMultiplier = 2.0; // 100% наценка
  } else if (numCny <= 100) {
    markupMultiplier = 1.6; // 60% наценка
  } else {
    markupMultiplier = 1.3; // 30% наценка
  }

  const productTjs = numCny * rate * markupMultiplier;
  const deliveryTjs = numWeight * 30; // 30 сомони за 1 кг веса

  return Math.max(1, Math.round(productTjs + deliveryTjs));
}

// Генераторы артикулов SKU
function generateBaseSku(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `MS-${code}`;
}

function generateVariantSku(baseSku: string, color?: string, size?: string): string {
  const cleanSize = (size || 'OS').replace(/[^a-zA-Z0-9]/g, '').slice(0, 4) || 'SZ';
  const randomHex = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `${baseSku}-${cleanSize}-${randomHex}`;
}

// ==========================================
// СИД НАЧАЛЬНЫХ ТОВАРОВ С МАТРИЦЕЙ ВАРИАНТОВ
// ==========================================
const countProducts = (db.prepare('SELECT COUNT(*) as count FROM products').get() as { count: number }).count;
if (countProducts === 0) {
  console.log('Наполнение базы профессиональными мульти-вариативными товарами...');

  const insertCat = db.prepare('INSERT INTO categories (name, parent_id) VALUES (?, ?)');
  insertCat.run('Мужская коллекция', null);
  insertCat.run('Женская коллекция', null);
  insertCat.run('Премиальная обувь', null);
  insertCat.run('Аудио и смарт-гаджеты', null);
  insertCat.run('Аксессуары и дом', null);

  const getCatId = (name: string) => (db.prepare('SELECT id FROM categories WHERE name = ?').get(name) as { id: number }).id;
  const menId = getCatId('Мужская коллекция');
  const shoesId = getCatId('Премиальная обувь');
  const techId = getCatId('Аудио и смарт-гаджеты');

  insertCat.run('Худи и толстовки', menId);
  insertCat.run('Кроссовки', shoesId);
  insertCat.run('Смарт-часы', techId);
  insertCat.run('Беспроводные наушники', techId);

  const hoodieCatId = getCatId('Худи и толстовки');
  const sneakersCatId = getCatId('Кроссовки');
  const watchCatId = getCatId('Смарт-часы');
  const audioCatId = getCatId('Беспроводные наушники');

  const insertProd = db.prepare(`
    INSERT INTO products (title, description, original_link, category_id, base_sku, status, main_image)
    VALUES (?, ?, ?, ?, ?, 'active', ?)
  `);

  const insertVar = db.prepare(`
    INSERT INTO product_variants (product_id, color, size, price_cny, price_tjs, stock, weight_kg, variant_sku, image_url)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  // Товар 1: Кроссовки с цветами и размерами
  const p1Sku = generateBaseSku();
  const p1Res = insertProd.run(
    'Мужские защитные дышащие кроссовки Hyper-Breeze',
    'Ультралегкие кроссовки из дышащего плетеного текстиля с анатомической подошвой EVA. Оптимальная амортизация для города и тренировок.',
    'https://detail.1688.com/offer/784192019.html',
    sneakersCatId,
    p1Sku,
    'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop'
  );
  const p1Id = Number(p1Res.lastInsertRowid);

  const colors1 = [
    { name: 'Черный оникс', img: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop', cny: 65, weight: 0.8 },
    { name: 'Графитовый серый', img: 'https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=800&auto=format&fit=crop', cny: 65, weight: 0.8 },
    { name: 'Белоснежный', img: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=800&auto=format&fit=crop', cny: 70, weight: 0.8 }
  ];
  const sizes1 = ['40', '41', '42', '43', '44'];

  for (const c of colors1) {
    for (const s of sizes1) {
      const priceTjs = calculateVariantPriceTjs(c.cny, c.weight);
      insertVar.run(p1Id, c.name, s, c.cny, priceTjs, Math.floor(5 + Math.random() * 15), c.weight, generateVariantSku(p1Sku, c.name, s), c.img);
    }
  }

  // Товар 2: Оверсайз худи Heavy Cotton
  const p2Sku = generateBaseSku();
  const p2Res = insertProd.run(
    'Оверсайз худи Heavy Cotton 450г/м² с мягким начесом',
    'Премиальный плотный хлопок с шелковистым внутренним начесом. Сохраняет форму после многократных стирок, свободный силуэт.',
    'https://detail.1688.com/offer/654129031.html',
    hoodieCatId,
    p2Sku,
    'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=800&auto=format&fit=crop'
  );
  const p2Id = Number(p2Res.lastInsertRowid);

  const colors2 = [
    { name: 'Глубокий черный', img: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=800&auto=format&fit=crop', cny: 88, weight: 0.7 },
    { name: 'Оливковый хаки', img: 'https://images.unsplash.com/photo-1509967419530-da38b4704bc6?w=800&auto=format&fit=crop', cny: 88, weight: 0.7 },
    { name: 'Песочный меланж', img: 'https://images.unsplash.com/photo-1578587018452-892bacefd3f2?w=800&auto=format&fit=crop', cny: 92, weight: 0.7 }
  ];
  const sizes2 = ['S', 'M', 'L', 'XL', '2XL'];

  for (const c of colors2) {
    for (const s of sizes2) {
      const priceTjs = calculateVariantPriceTjs(c.cny, c.weight);
      insertVar.run(p2Id, c.name, s, c.cny, priceTjs, Math.floor(4 + Math.random() * 10), c.weight, generateVariantSku(p2Sku, c.name, s), c.img);
    }
  }

  // Товар 3: Смарт-часы Titanium Ultra
  const p3Sku = generateBaseSku();
  const p3Res = insertProd.run(
    'Смарт-часы Titanium Series Ultra AMOLED',
    'Флагманский титановый корпус, дисплей сапфирового класса 1000 нит, датчики пульса и кислорода, автономность до 12 дней.',
    'https://mobile.yangkeduo.com/goods.html?goods_id=89123019',
    watchCatId,
    p3Sku,
    'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=800&auto=format&fit=crop'
  );
  const p3Id = Number(p3Res.lastInsertRowid);

  const watchVariants = [
    { color: 'Титановый с черным ремешком', size: '49mm', cny: 145, weight: 0.35, img: 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=800&auto=format&fit=crop' },
    { color: 'Серебристый со стальным браслетом', size: '49mm', cny: 165, weight: 0.45, img: 'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=800&auto=format&fit=crop' },
    { color: 'Оранжевый трейл', size: '49mm', cny: 145, weight: 0.35, img: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop' }
  ];

  for (const w of watchVariants) {
    const priceTjs = calculateVariantPriceTjs(w.cny, w.weight);
    insertVar.run(p3Id, w.color, w.size, w.cny, priceTjs, 12, w.weight, generateVariantSku(p3Sku, w.color, w.size), w.img);
  }

  // Товар 4: Наушники ANC Pro
  const p4Sku = generateBaseSku();
  const p4Res = insertProd.run(
    'Беспроводные наушники Clarity ANC Pro с пространственным аудио',
    'Гибридное активное шумоподавление до -40dB, динамические драйверы 12мм, 32 часа автономной работы с футляром Type-C.',
    'https://detail.1688.com/offer/912830112.html',
    audioCatId,
    p4Sku,
    'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&auto=format&fit=crop'
  );
  const p4Id = Number(p4Res.lastInsertRowid);

  const audioVariants = [
    { color: 'Матовый черный', size: 'Стандарт', cny: 48, weight: 0.25, img: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&auto=format&fit=crop' },
    { color: 'Жемчужно-белый', size: 'Стандарт', cny: 48, weight: 0.25, img: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop' }
  ];

  for (const a of audioVariants) {
    const priceTjs = calculateVariantPriceTjs(a.cny, a.weight);
    insertVar.run(p4Id, a.color, a.size, a.cny, priceTjs, 25, a.weight, generateVariantSku(p4Sku, a.color, a.size), a.img);
  }
}

// ==========================================
// ИНТЕЛЛЕКТУАЛЬНЫЙ РАЗБОР СТРАНИЦЫ ИЗ GEMINI
// ==========================================
interface ParsedVariant {
  color: string;
  size: string;
  price_cny: number;
  stock: number;
  weight_kg?: number;
  image_url?: string;
}

interface GeminiAnalysisResult {
  title: string;
  description: string;
  category_name: string;
  weight_kg: number;
  variants: ParsedVariant[];
}

function cleanRawTitle(raw: string): string {
  return raw
    .replace(/【.*?】/g, '')
    .replace(/\[.*?\]/g, '')
    .replace(/[-|_].*$/g, '')
    .replace(/(批发|厂家直销|现货|包邮|爆款|2026新款|跨境|一件代发)/g, '')
    .trim() || 'Эксклюзивный товар';
}

function fallbackAnalysis(rawText: string, rawTitle?: string, baseCny: number = 50, weightKg: number = 0.5): GeminiAnalysisResult {
  return analyzeSemantically(rawText, rawTitle, baseCny, weightKg);
}

interface VisualSkuItem {
  raw_color: string;
  image_url: string;
}

const COLOR_TRANSLATION_MAP: Record<string, string[]> = {
  'черный': ['黑', 'black'],
  'белый': ['白', 'white'],
  'серый': ['灰', 'gray', 'grey'],
  'синий': ['蓝', 'blue', 'cyan'],
  'голубой': ['天蓝', '浅蓝', 'blue'],
  'красный': ['红', 'red'],
  'розовый': ['粉', 'pink'],
  'желтый': ['黄', 'yellow'],
  'зеленый': ['绿', 'green'],
  'коричневый': ['棕', '咖啡', '咖', 'brown', 'coffee'],
  'кофейный': ['咖', '咖啡', 'coffee', 'brown'],
  'бежевый': ['米', '卡其', 'beige', 'khaki'],
  'хаки': ['卡其', '军绿', 'khaki'],
  'оранжевый': ['橙', 'orange'],
  'фиолетовый': ['紫', 'purple'],
  'бордовый': ['酒红', 'burgundy']
};

function matchColorWithVisualMap(colorRu: string, visualSkuMap: VisualSkuItem[]): string {
  if (!visualSkuMap || visualSkuMap.length === 0) return '';
  const lowerRu = colorRu.toLowerCase();

  // 1. Поиск по ключевым китайским иероглифам из словаря
  for (const [ruKey, cnTokens] of Object.entries(COLOR_TRANSLATION_MAP)) {
    if (lowerRu.includes(ruKey)) {
      for (const item of visualSkuMap) {
        for (const token of cnTokens) {
          if (item.raw_color.includes(token)) {
            return item.image_url;
          }
        }
      }
    }
  }

  // 2. Если в самом названии цвета есть китайские иероглифы
  for (const item of visualSkuMap) {
    if (item.raw_color.includes(colorRu) || colorRu.includes(item.raw_color)) {
      return item.image_url;
    }
  }

  return '';
}

async function analyzeProductWithGemini(
  rawText: string,
  rawTitle?: string,
  basePriceCny: number = 50,
  weightKg: number = 0.5,
  visualSkuMap: VisualSkuItem[] = []
): Promise<GeminiAnalysisResult> {
  if (!aiClient) {
    console.log('[Gemini] GEMINI_API_KEY отсутствует, используется автономный семантический анализ.');
    const fallback = analyzeSemantically(rawText, rawTitle, basePriceCny, weightKg);
    // Привязываем фото из карты
    for (const v of fallback.variants) {
      const matchedImg = matchColorWithVisualMap(v.color, visualSkuMap);
      if (matchedImg) v.image_url = matchedImg;
    }
    return fallback;
  }

  try {
    const textSnippet = rawText.slice(0, 18000);
    const skuMapSnippet = JSON.stringify(visualSkuMap || [], null, 2);

    const prompt = `Ты — ведущий международный e-commerce аналитик сервиса M.Savdo (Душанбе, Таджикистан).
Тебе передан сырой текст страницы китайского маркетплейса (1688 / Pinduoduo / Taobao) и массив привязки цветов к фотографиям (visual_sku_map).

ТВОЯ ЗАДАЧА:
1. "title": Переведи и сформулируй чистое, красивое название товара на РУССКОМ языке для клиентской витрины.
   СТРОГО удали: слова Alibaba, 1688, оптом, 2026, 2025, фабрика, завод, производитель, фабричные названия (например: "温县干恒制鞋厂", "中山市..."), рекламный спам, китайские иероглифы.
2. "description": Создай продающее описание ровно из 3 предложений на русском языке: 1) Материалы и качество исполнения, 2) Фасон, анатомическая посадка и удобство, 3) Ключевые преимущества и долговечность.
3. "category_name": Выбери наиболее подходящую категорию СТРОГО из списка:
   - "Мужская коллекция"
   - "Женская коллекция"
   - "Премиальная обувь"
   - "Аудио и смарт-гаджеты"
   - "Игрушки и хобби"
4. "weight_kg": Извлеки вес единицы товара в кг (например, 0.75). Если вес не указан, оцени разумно (обувь ~0.8, куртка ~0.8, худи ~0.65, смарт-часы ~0.3, мелкие аксессуары ~0.15).
5. "variants": Сформируй полную матрицу модификаций товара (цвета и РЕАЛЬНЫЕ размеры из текста).
   КРИТИЧЕСКИ ВАЖНО:
   - Найди в тексте все РЕАЛЬНЫЕ размеры (например: 39, 40, 41, 42, 43, 44 или S, M, L, XL, 2XL или "Стандарт").
   - "color": Красивое название цвета на русском языке (например: "Черный", "Белый", "Графитовый серый", "Кофейный", "Оливковый").
   - "size": Размер товара ("39", "40", "41", "42", "43", "44", "S", "M", "L", "XL" или "Стандарт").
   - "price_cny": Индивидуальная цена в юанях из текста для этого варианта (если указана), иначе ${basePriceCny}.
   - "stock": 25.
   - "weight_kg": Вес варианта в кг.
   - "image_url": НАЙДИ в visual_sku_map соответствующий китайский цвет (например, для "Черный" найди "黑色", для "Кофейный" найди "咖色" или "D107轻便耐磨【咖色】") и вставь сюда ПРЯМУЮ ССЫЛКУ НА ЕГО КАРТИНКУ из visual_sku_map! Если соответствия нет, оставь пустую строку "".

Карта соответствия цветов и фотографий visual_sku_map:
${skuMapSnippet}

Заголовок со страницы: "${rawTitle || ''}"
Базовая цена по умолчанию: ${basePriceCny} CNY
Текстовый слой страницы товара:
"""
${textSnippet}
"""

Верни СТРОГО JSON-объект следующего формата:
{
  "title": "Строка",
  "description": "Строка",
  "category_name": "Категория строго из разрешенного списка",
  "weight_kg": 0.5,
  "variants": [
    {
      "color": "Цвет на русском",
      "size": "Размер",
      "price_cny": 50.0,
      "stock": 25,
      "weight_kg": 0.5,
      "image_url": "https://..."
    }
  ]
}`;

    const timeoutPromise = new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error('Таймаут Gemini API (9с)')), 9000)
    );

    const generatePromise = aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const response = await Promise.race([generatePromise, timeoutPromise]);
    const responseText = response.text?.trim() || '{}';
    const parsed = JSON.parse(responseText);

    const title = parsed.title?.trim() || cleanRawTitle(rawTitle || rawText.slice(0, 80));
    const description = parsed.description?.trim() || 'Высококачественный фабричный товар, прошедший проверку отделом контроля качества M.Savdo.';
    const category_name = parsed.category_name || 'Мужская коллекция';
    const weight_kg = typeof parsed.weight_kg === 'number' && parsed.weight_kg > 0 ? parsed.weight_kg : weightKg;

    const variants: ParsedVariant[] = [];
    if (Array.isArray(parsed.variants) && parsed.variants.length > 0) {
      for (const v of parsed.variants) {
        let vImg = (v.image_url || '').trim();
        // Если Gemini не привязал картинку, применяем алгоритмический сопоставитель
        if (!vImg) {
          vImg = matchColorWithVisualMap(String(v.color || ''), visualSkuMap);
        }

        variants.push({
          color: String(v.color || 'Основной цвет').trim(),
          size: String(v.size || 'Стандарт').trim(),
          price_cny: parseFloat(v.price_cny) || basePriceCny,
          stock: parseInt(v.stock, 10) || 25,
          weight_kg: parseFloat(v.weight_kg) || weight_kg,
          image_url: vImg,
        });
      }
    } else {
      variants.push({
        color: 'Основной цвет',
        size: 'Стандарт',
        price_cny: basePriceCny,
        stock: 25,
        weight_kg: weight_kg,
        image_url: visualSkuMap[0]?.image_url || '',
      });
    }

    return {
      title,
      description,
      category_name,
      weight_kg,
      variants,
    };
  } catch (err: any) {
    console.warn('[Gemini AI Parse Error]', err.message);
    const fb = fallbackAnalysis(rawText, rawTitle, basePriceCny, weightKg);
    for (const v of fb.variants) {
      const matched = matchColorWithVisualMap(v.color, visualSkuMap);
      if (matched) v.image_url = matched;
    }
    return fb;
  }
}

// Привязка или создание категории
function resolveCategoryId(catName: string): number {
  const existing = db.prepare('SELECT id FROM categories WHERE lower(name) = lower(?)').get(catName) as { id: number } | undefined;
  if (existing) return existing.id;

  const all = db.prepare('SELECT id, name FROM categories').all() as Array<{ id: number; name: string }>;
  for (const c of all) {
    if (catName.toLowerCase().includes(c.name.toLowerCase()) || c.name.toLowerCase().includes(catName.toLowerCase())) {
      return c.id;
    }
  }

  const res = db.prepare('INSERT INTO categories (name, parent_id) VALUES (?, NULL)').run(catName);
  return Number(res.lastInsertRowid);
}

// Автоматическое определение категории через Gemini 3.8 Flash
const STRICT_ALLOWED_CATEGORIES = [
  'Мужская коллекция',
  'Женская коллекция',
  'Премиальная обувь',
  'Аудио и смарт-гаджеты',
  'Игрушки и хобби',
];

async function resolveCategoryWithAi(title: string): Promise<string> {
  const cleanTitle = (title || '').trim();
  if (!cleanTitle) return 'Мужская коллекция';

  if (!aiClient) {
    const lower = cleanTitle.toLowerCase();
    if (lower.includes('обувь') || lower.includes('кроссов') || lower.includes('туфл') || lower.includes('ботин') || lower.includes('кеды') || lower.includes('сапог') || lower.includes('лофер')) {
      return 'Премиальная обувь';
    }
    if (lower.includes('женск') || lower.includes('платье') || lower.includes('юбк') || lower.includes('сумк') || lower.includes('блузк') || lower.includes('косметик')) {
      return 'Женская коллекция';
    }
    if (lower.includes('наушник') || lower.includes('часы') || lower.includes('гаджет') || lower.includes('аудио') || lower.includes('смарт') || lower.includes('bluetooth') || lower.includes('кабель') || lower.includes('колонк')) {
      return 'Аудио и смарт-гаджеты';
    }
    if (lower.includes('игрушк') || lower.includes('детск') || lower.includes('хобби') || lower.includes('конструктор') || lower.includes('лего') || lower.includes('кукл') || lower.includes('машинк')) {
      return 'Игрушки и хобби';
    }
    return 'Мужская коллекция';
  }

  try {
    const prompt = `Определи точную категорию для товара '${cleanTitle}'. Выбери строго один вариант из существующих: Мужская коллекция, Женская коллекция, Премиальная обувь, Аудио и смарт-гаджеты, Игрушки и хобби. Верни только название категории.`;

    const timeoutPromise = new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error('AI Category Timeout')), 6000)
    );

    const generatePromise = aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
    });

    const resp = await Promise.race([generatePromise, timeoutPromise]);
    const rawCat = resp.text ? resp.text.trim().replace(/["'`.]/g, '') : '';
    
    for (const cat of STRICT_ALLOWED_CATEGORIES) {
      if (rawCat.toLowerCase().includes(cat.toLowerCase()) || cat.toLowerCase().includes(rawCat.toLowerCase())) {
        return cat;
      }
    }
    return 'Мужская коллекция';
  } catch (err: any) {
    console.warn('[Gemini AI Category Warning]', err.message);
    const lower = cleanTitle.toLowerCase();
    if (lower.includes('обувь') || lower.includes('кроссов') || lower.includes('туфл') || lower.includes('ботин')) {
      return 'Премиальная обувь';
    }
    if (lower.includes('женск') || lower.includes('платье') || lower.includes('юбк')) {
      return 'Женская коллекция';
    }
    if (lower.includes('наушник') || lower.includes('часы') || lower.includes('аудио') || lower.includes('смарт')) {
      return 'Аудио и смарт-гаджеты';
    }
    if (lower.includes('игрушк') || lower.includes('детск') || lower.includes('хобби')) {
      return 'Игрушки и хобби';
    }
    return 'Мужская коллекция';
  }
}

// ==========================================
// МИДЛВЕЙР АВТОРИЗАЦИИ АДМИНИСТРАТОРА
// ==========================================
function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Доступ запрещен: требуется авторизация администратора' });
  }

  const token = authHeader.split(' ')[1];
  if (!activeAdminTokens.has(token)) {
    return res.status(401).json({ error: 'Недействительный или истекший токен сессии' });
  }

  next();
}

// ==========================================
// REST API МАРШРУТЫ
// ==========================================

// 1. АВТОРИЗАЦИЯ АДМИНИСТРАТОРА
app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Укажите имя пользователя и пароль' });
  }

  const user = db.prepare('SELECT * FROM admin_users WHERE username = ?').get(username) as { id: number; username: string; password_hash: string } | undefined;
  if (!user || user.password_hash !== hashPassword(password)) {
    return res.status(401).json({ error: 'Неверный логин или пароль администратора' });
  }

  const token = crypto.randomBytes(32).toString('hex');
  activeAdminTokens.add(token);

  return res.json({
    success: true,
    token,
    user: { id: user.id, username: user.username }
  });
});

app.get('/api/admin/check', requireAdmin, (req, res) => {
  return res.json({ authenticated: true });
});

app.post('/api/admin/logout', requireAdmin, (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (token) activeAdminTokens.delete(token);
  return res.json({ success: true });
});

// 2. ПУБЛИЧНЫЙ КАТАЛОГ ДЛЯ КЛИЕНТОВ (ПОЛНАЯ ИЗОЛЯЦИЯ: НЕТ CNY, НЕТ 1688, НЕТ ССЫЛОК)
app.get('/api/products', (req, res) => {
  try {
    const { search, category_id } = req.query;

    let query = `
      SELECT p.id, p.title, p.description, p.category_id, p.base_sku, p.status, p.delivery_type, p.main_image, p.images, p.video_url, p.youtube_url, p.created_at,
             c.name as category_name
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE p.status = 'active'
    `;
    const params: any[] = [];

    if (search) {
      query += ' AND (p.title LIKE ? OR p.base_sku LIKE ? OR p.description LIKE ?)';
      const term = `%${search}%`;
      params.push(term, term, term);
    }

    if (category_id) {
      const catId = Number(category_id);
      query += ' AND (p.category_id = ? OR p.category_id IN (SELECT id FROM categories WHERE parent_id = ?))';
      params.push(catId, catId);
    }

    query += ' ORDER BY p.id DESC';
    const products = db.prepare(query).all(...params) as any[];

    // Прикрепляем варианты (строго без price_cny для защиты коммерческой тайны!)
    const getVariants = db.prepare(`
      SELECT id, product_id, color, size, price_tjs, stock, weight_kg, variant_sku, image_url
      FROM product_variants
      WHERE product_id = ?
      ORDER BY id ASC
    `);

    // Используем безопасный цикл for ... of (без .map)
    const enriched: any[] = [];
    for (const p of products) {
      const variants = getVariants.all(p.id) as any[];
      let minPrice = 0;
      let maxPrice = 0;
      if (variants.length > 0) {
        let minVal = Infinity;
        let maxVal = -Infinity;
        for (const v of variants) {
          if (v.price_tjs > 0) {
            if (v.price_tjs < minVal) minVal = v.price_tjs;
            if (v.price_tjs > maxVal) maxVal = v.price_tjs;
          }
        }
        if (minVal !== Infinity) {
          minPrice = minVal;
          maxPrice = maxVal;
        }
      }

      enriched.push({
        ...p,
        delivery_type: p.delivery_type || 'order',
        youtube_url: p.youtube_url || p.video_url || '',
        video_url: p.youtube_url || p.video_url || '',
        min_price_tjs: minPrice,
        max_price_tjs: maxPrice,
        variants,
      });
    }

    return res.json({ products: enriched });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// 3. АДМИНСКИЙ КАТАЛОГ (ДОСТУПЕН ТОЛЬКО АВТОРИЗОВАННОМУ АДМИНУ)
app.get('/api/admin/products', requireAdmin, (req, res) => {
  try {
    const products = db.prepare(`
      SELECT p.*, c.name as category_name
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      ORDER BY p.id DESC
    `).all() as any[];

    const getVariants = db.prepare(`SELECT * FROM product_variants WHERE product_id = ? ORDER BY id ASC`);

    const enriched: any[] = [];
    for (const p of products) {
      const variants = getVariants.all(p.id);
      enriched.push({
        ...p,
        delivery_type: p.delivery_type || 'order',
        youtube_url: p.youtube_url || p.video_url || '',
        video_url: p.youtube_url || p.video_url || '',
        variants,
      });
    }

    return res.json({ products: enriched });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// 4. СОЗДАНИЕ ТОВАРА ВРУЧНУЮ В АДМИНКЕ С ИИ-КАТЕГОРИЗАЦИЕЙ
app.post('/api/admin/products', requireAdmin, async (req, res) => {
  try {
    const {
      title,
      description = '',
      delivery_type = 'order',
      status = 'active',
      main_image = '',
      images = '',
      video_url = '',
      youtube_url = '',
      variants = [],
    } = req.body;

    if (!title || typeof title !== 'string' || !title.trim()) {
      return res.status(400).json({ error: 'Название товара обязательно' });
    }

    const cleanTitle = title.trim();
    const cleanDesc = (description || '').trim();
    const cleanDelivery = delivery_type === 'stock' ? 'stock' : 'order';
    const cleanStatus = status === 'draft' ? 'draft' : 'active';
    const cleanVideo = (typeof youtube_url === 'string' && youtube_url.trim())
      ? youtube_url.trim()
      : (typeof video_url === 'string' ? video_url.trim() : '');

    // ИИ-определение категории через Gemini 3.8 Flash
    const aiCategory = await resolveCategoryWithAi(cleanTitle);
    const categoryId = resolveCategoryId(aiCategory);

    // Нормализация изображений
    let allImages = '';
    let mImage = (main_image || '').trim();
    if (Array.isArray(images) && images.length > 0) {
      const cleanImgArr: string[] = [];
      for (const img of images) {
        if (typeof img === 'string' && img.trim()) cleanImgArr.push(img.trim());
      }
      allImages = cleanImgArr.join(',');
      if (!mImage && cleanImgArr.length > 0) mImage = cleanImgArr[0];
    } else if (typeof images === 'string') {
      allImages = images.trim();
      if (!mImage && allImages) mImage = allImages.split(',')[0].trim();
    }

    const baseSku = generateBaseSku();

    const insertProd = db.prepare(`
      INSERT INTO products (title, description, category_id, base_sku, status, delivery_type, main_image, images, video_url, youtube_url)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(cleanTitle, cleanDesc, categoryId, baseSku, cleanStatus, cleanDelivery, mImage, allImages, cleanVideo, cleanVideo);

    const productId = Number(insertProd.lastInsertRowid);

    // Сохранение вариантов
    const insertVar = db.prepare(`
      INSERT INTO product_variants (product_id, color, size, price_cny, price_tjs, stock, weight_kg, variant_sku, image_url)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const createdVars: any[] = [];
    if (Array.isArray(variants) && variants.length > 0) {
      for (const v of variants) {
        const vColor = (v.color || 'Основной цвет').trim();
        const vSize = (v.size || 'Стандарт').trim();
        const vWeight = parseFloat(v.weight_kg) || 0.5;
        const vCny = parseFloat(v.price_cny) || 0;
        const vTjs = parseInt(v.price_tjs, 10) || calculateVariantPriceTjs(vCny || 50, vWeight);
        const vStock = parseInt(v.stock, 10) || 10;
        const vSku = generateVariantSku(baseSku, vColor, vSize);
        const vImg = (v.image_url || mImage || '').trim();

        insertVar.run(productId, vColor, vSize, vCny, vTjs, vStock, vWeight, vSku, vImg);
        createdVars.push({
          color: vColor,
          size: vSize,
          price_tjs: vTjs,
          stock: vStock,
          weight_kg: vWeight,
          variant_sku: vSku,
          image_url: vImg,
        });
      }
    } else {
      const defaultPriceTjs = 120;
      const defaultSku = generateVariantSku(baseSku, 'Основной', 'Стандарт');
      insertVar.run(productId, 'Основной', 'Стандарт', 0, defaultPriceTjs, 15, 0.5, defaultSku, mImage);
      createdVars.push({
        color: 'Основной',
        size: 'Стандарт',
        price_tjs: defaultPriceTjs,
        stock: 15,
        weight_kg: 0.5,
        variant_sku: defaultSku,
        image_url: mImage,
      });
    }

    return res.status(201).json({
      success: true,
      product: {
        id: productId,
        base_sku: baseSku,
        title: cleanTitle,
        category_id: categoryId,
        category_name: aiCategory,
        delivery_type: cleanDelivery,
        youtube_url: cleanVideo,
        video_url: cleanVideo,
        variants: createdVars,
      },
    });
  } catch (err: any) {
    console.error('[Admin Create Product Error]', err);
    return res.status(500).json({ error: err.message });
  }
});

// 5. ПОЛНОЦЕННОЕ РЕДАКТИРОВАНИЕ ТОВАРА В АДМИНКЕ С ИИ-КАТЕГОРИЗАЦИЕЙ
app.put('/api/admin/products/:id', requireAdmin, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const {
      title,
      description = '',
      delivery_type = 'order',
      status = 'active',
      main_image = '',
      images = '',
      video_url = '',
      youtube_url = '',
      default_weight_kg,
      variants,
    } = req.body;

    if (!title || typeof title !== 'string' || !title.trim()) {
      return res.status(400).json({ error: 'Название товара обязательно' });
    }

    const cleanTitle = title.trim();
    const cleanDesc = (description || '').trim();
    const cleanDelivery = delivery_type === 'stock' ? 'stock' : 'order';
    const cleanStatus = status === 'draft' ? 'draft' : 'active';
    const cleanVideo = (typeof youtube_url === 'string' && youtube_url.trim())
      ? youtube_url.trim()
      : (typeof video_url === 'string' ? video_url.trim() : '');

    // ИИ-определение точной категории через Gemini 3.8 Flash
    const aiCategory = await resolveCategoryWithAi(cleanTitle);
    const categoryId = resolveCategoryId(aiCategory);

    // Нормализация изображений
    let allImages = '';
    let mImage = (main_image || '').trim();
    if (Array.isArray(images) && images.length > 0) {
      const cleanImgArr: string[] = [];
      for (const img of images) {
        if (typeof img === 'string' && img.trim()) cleanImgArr.push(img.trim());
      }
      allImages = cleanImgArr.join(',');
      if (!mImage && cleanImgArr.length > 0) mImage = cleanImgArr[0];
    } else if (typeof images === 'string') {
      allImages = images.trim();
      if (!mImage && allImages) mImage = allImages.split(',')[0].trim();
    }

    // Получаем текущий базовый артикул
    const existingProd = db.prepare('SELECT base_sku FROM products WHERE id = ?').get(id) as { base_sku: string } | undefined;
    const baseSku = existingProd ? existingProd.base_sku : generateBaseSku();

    // Обновляем карточку товара
    db.prepare(`
      UPDATE products
      SET title = ?, description = ?, category_id = ?, status = ?, delivery_type = ?, main_image = ?, images = ?, video_url = ?, youtube_url = ?
      WHERE id = ?
    `).run(cleanTitle, cleanDesc, categoryId, cleanStatus, cleanDelivery, mImage, allImages, cleanVideo, cleanVideo, id);

    // Если передан полный обновленный массив вариантов: синхронизируем матрицу
    if (Array.isArray(variants) && variants.length > 0) {
      db.prepare('DELETE FROM product_variants WHERE product_id = ?').run(id);

      const insertVar = db.prepare(`
        INSERT INTO product_variants (product_id, color, size, price_cny, price_tjs, stock, weight_kg, variant_sku, image_url)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      for (const v of variants) {
        const vColor = (v.color || 'Основной цвет').trim();
        const vSize = (v.size || 'Стандарт').trim();
        const vWeight = parseFloat(v.weight_kg) || 0.5;
        const vCny = parseFloat(v.price_cny) || 0;
        const vTjs = parseInt(v.price_tjs, 10) || calculateVariantPriceTjs(vCny || 50, vWeight);
        const vStock = parseInt(v.stock, 10) || 10;
        const vSku = v.variant_sku || generateVariantSku(baseSku, vColor, vSize);
        const vImg = (v.image_url || mImage || '').trim();

        insertVar.run(id, vColor, vSize, vCny, vTjs, vStock, vWeight, vSku, vImg);
      }
    } else if (default_weight_kg !== undefined && default_weight_kg !== null) {
      // Иначе если просто передан новый вес: пересчитываем существующие варианты
      const weightNum = parseFloat(default_weight_kg) || 0.5;
      const currentVars = db.prepare('SELECT id, price_cny FROM product_variants WHERE product_id = ?').all(id) as Array<{ id: number; price_cny: number }>;

      const updateVar = db.prepare('UPDATE product_variants SET weight_kg = ?, price_tjs = ? WHERE id = ?');
      for (const v of currentVars) {
        const newTjs = calculateVariantPriceTjs(v.price_cny, weightNum);
        updateVar.run(weightNum, newTjs, v.id);
      }
    }

    return res.json({
      success: true,
      message: 'Товар, матрица вариантов и категория успешно обновлены',
      category_name: aiCategory,
      category_id: categoryId,
    });
  } catch (err: any) {
    console.error('[Admin Update Product Error]', err);
    return res.status(500).json({ error: err.message });
  }
});

// 6. РЕДАКТИРОВАНИЕ КОНКРЕТНОГО ВАРИАНТА В АДМИНКЕ
app.put('/api/admin/variants/:id', requireAdmin, (req, res) => {
  try {
    const id = Number(req.params.id);
    const { color, size, price_cny, price_tjs, weight_kg, stock, image_url } = req.body;

    const cnyNum = parseFloat(price_cny) || 0;
    const weightNum = parseFloat(weight_kg) || 0.5;
    const stockNum = parseInt(stock, 10) || 0;
    const finalTjs = price_tjs !== undefined ? (parseInt(price_tjs, 10) || 0) : calculateVariantPriceTjs(cnyNum, weightNum);
    const cleanImg = typeof image_url === 'string' ? image_url.trim() : '';

    db.prepare(`
      UPDATE product_variants
      SET color = ?, size = ?, price_cny = ?, price_tjs = ?, weight_kg = ?, stock = ?, image_url = CASE WHEN ? != '' THEN ? ELSE image_url END
      WHERE id = ?
    `).run(color, size, cnyNum, finalTjs, weightNum, stockNum, cleanImg, cleanImg, id);

    return res.json({ success: true, price_tjs: finalTjs });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// 7. УДАЛЕНИЕ ТОВАРА
app.delete('/api/admin/products/:id', requireAdmin, (req, res) => {
  try {
    const id = Number(req.params.id);
    db.prepare('DELETE FROM products WHERE id = ?').run(id);
    return res.json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// 7. ИНТЕЛЛЕКТУАЛЬНЫЙ ИМПОРТ ИЗ CHROME-РАСШИРЕНИЯ С АНАЛИЗОМ СЫРОГО ТЕКСТА ЧЕРЕЗ GEMINI
app.post('/api/add-product', async (req, res) => {
  try {
    const {
      raw_html_text = '',
      raw_text = '',
      title: inputTitle = '',
      raw_title: inputRawTitle = '',
      description: inputDesc = '',
      original_link = '',
      images = '',
      visual_sku_map = [],
      video_url = '',
      price_cny = 50,
      weight_kg = 0.5,
      variants: manualVariants = [],
      status = 'active',
      delivery_type = 'order',
      youtube_url = '',
    } = req.body;

    const fullRawText = (raw_html_text || raw_text || '').trim();
    const effectiveTitle = (inputRawTitle || inputTitle || '').trim();
    const baseCny = parseFloat(price_cny) || 50;
    const initialWeight = parseFloat(weight_kg) || 0.5;
    const cleanVideoUrl = typeof video_url === 'string' ? video_url.trim() : '';
    const cleanYoutubeUrl = typeof youtube_url === 'string' && youtube_url.trim() ? youtube_url.trim() : cleanVideoUrl;
    const finalDeliveryType = delivery_type === 'stock' ? 'stock' : 'order';

    console.log('[API Import] Запрос на импорт товара. Длина текста:', fullRawText.length, 'Карт картинок:', visual_sku_map.length);

    let finalTitle = effectiveTitle;
    let finalDesc = inputDesc;
    let finalCategory = 'Мужская коллекция';
    let finalWeight = initialWeight;
    let variantsToProcess: ParsedVariant[] = [];

    // Приоритет разбора: Gemini 3.8 Flash
    if (aiClient && fullRawText.length > 50) {
      console.log('[Gemini 3.8 Flash] Интеллектуальный разбор с привязкой картинок visual_sku_map...');
      const aiAnalysis = await analyzeProductWithGemini(fullRawText, effectiveTitle, baseCny, initialWeight, visual_sku_map);
      finalTitle = aiAnalysis.title || effectiveTitle;
      finalDesc = inputDesc || aiAnalysis.description;
      finalCategory = aiAnalysis.category_name;
      finalWeight = aiAnalysis.weight_kg;
      variantsToProcess = aiAnalysis.variants;
    } else if (Array.isArray(manualVariants) && manualVariants.length > 0) {
      console.log(`[API Import] Использование готовых вариантов (${manualVariants.length} шт.).`);
      variantsToProcess = manualVariants;
      finalTitle = effectiveTitle || 'Товар M.Savdo';
      finalDesc = inputDesc || 'Высококачественный фабричный товар каталога M.Savdo.';
      const sem = analyzeSemantically(fullRawText, effectiveTitle, baseCny, initialWeight);
      finalCategory = sem.category_name;
      finalWeight = initialWeight;
    } else {
      console.log('[API Import] Запуск автономного семантического разбора...');
      const fb = fallbackAnalysis(fullRawText, effectiveTitle, baseCny, initialWeight);
      finalTitle = fb.title;
      finalDesc = inputDesc || fb.description;
      finalCategory = fb.category_name;
      finalWeight = fb.weight_kg;
      variantsToProcess = fb.variants;
    }

    // Если в названии остались китайские иероглифы или фабричные токены
    if (
      !finalTitle ||
      finalTitle.length < 5 ||
      /[\u4e00-\u9fa5]/.test(finalTitle) ||
      finalTitle.includes('厂') ||
      finalTitle.includes('公司') ||
      finalTitle.includes('温县') ||
      finalTitle.includes('中山市')
    ) {
      const semantic = analyzeSemantically(fullRawText, effectiveTitle, baseCny, initialWeight);
      finalTitle = semantic.title;
      if (!inputDesc || /[\u4e00-\u9fa5]/.test(inputDesc)) finalDesc = semantic.description;
      finalCategory = semantic.category_name;
    }

    // Привязываем категорию
    const categoryId = resolveCategoryId(finalCategory);

    // Генерируем уникальный артикул базового товара
    const baseSku = generateBaseSku();

    // Извлекаем изображения
    let allImages = '';
    let mainImage = '';
    if (Array.isArray(images) && images.length > 0) {
      const cleanImgArr: string[] = [];
      for (const img of images) {
        if (typeof img === 'string' && img.trim()) cleanImgArr.push(img.trim());
      }
      allImages = cleanImgArr.join(',');
      mainImage = cleanImgArr[0] || '';
    } else if (typeof images === 'string' && images.length > 0) {
      allImages = images.trim();
      mainImage = images.split(',')[0].trim();
    }

    // Сохраняем товар в базу со всеми фото и видео (по умолчанию под заказ: 15-30 дней)
    const prodInsert = db.prepare(`
      INSERT INTO products (title, description, original_link, category_id, base_sku, status, delivery_type, main_image, images, video_url, youtube_url)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(finalTitle, finalDesc, original_link, categoryId, baseSku, status, finalDeliveryType, mainImage, allImages, cleanVideoUrl, cleanYoutubeUrl);

    const productId = Number(prodInsert.lastInsertRowid);

    // Записываем варианты
    const varInsert = db.prepare(`
      INSERT INTO product_variants (product_id, color, size, price_cny, price_tjs, stock, weight_kg, variant_sku, image_url)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const createdVariants: any[] = [];

    if (variantsToProcess.length === 0) {
      variantsToProcess.push({
        color: 'Основной вариант',
        size: 'Стандарт',
        price_cny: baseCny,
        stock: 20,
        weight_kg: finalWeight,
      });
    }

    for (const v of variantsToProcess) {
      const vCny = parseFloat(v.price_cny as any) || baseCny;
      const vWeight = parseFloat(v.weight_kg as any) || finalWeight;
      const vPriceTjs = calculateVariantPriceTjs(vCny, vWeight);
      const vColor = translateVariantName(v.color || 'Основной вариант');
      const vSize = translateVariantName(v.size || 'Стандарт');
      const vStock = parseInt(v.stock as any, 10) || 15;
      const vSku = generateVariantSku(baseSku, vColor, vSize);
      const vImg = v.image_url || mainImage;

      varInsert.run(productId, vColor, vSize, vCny, vPriceTjs, vStock, vWeight, vSku, vImg);

      createdVariants.push({
        color: vColor,
        size: vSize,
        price_cny: vCny,
        price_tjs: vPriceTjs,
        variant_sku: vSku,
        stock: vStock,
        weight_kg: vWeight,
      });
    }

    console.log(`✓ Товар успешно создан: ID=${productId}, Артикул=${baseSku}, Вариантов=${createdVariants.length}`);

    return res.status(201).json({
      status: 'success',
      message: 'Товар успешно импортирован и интеллектуально разобран ИИ',
      product: {
        id: productId,
        base_sku: baseSku,
        title: finalTitle,
        category_id: categoryId,
        category_name: finalCategory,
        weight_kg: finalWeight,
        delivery_type: finalDeliveryType,
        youtube_url: cleanYoutubeUrl,
        variants_count: createdVariants.length,
        variants: createdVariants,
      },
    });
  } catch (err: any) {
    console.error('[API Import Error]', err);
    return res.status(500).json({ status: 'error', message: err.message });
  }
});

// 8. КАТЕГОРИИ (ДВУХУРОВНЕВОЕ ДЕРЕВО)
app.get('/api/categories', (_req, res) => {
  try {
    const rootCats = db.prepare('SELECT id, name FROM categories WHERE parent_id IS NULL ORDER BY name ASC').all() as Array<{ id: number; name: string }>;
    const getSubs = db.prepare('SELECT id, name FROM categories WHERE parent_id = ? ORDER BY name ASC');

    const tree: any[] = [];
    for (const root of rootCats) {
      const subcategories = getSubs.all(root.id);
      tree.push({
        ...root,
        subcategories,
      });
    }

    const all = db.prepare('SELECT id, name, parent_id FROM categories ORDER BY name ASC').all();
    return res.json({ tree, all });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

app.post('/api/admin/categories', requireAdmin, (req, res) => {
  try {
    const { name, parent_id } = req.body;
    if (!name) return res.status(400).json({ error: 'Название категории обязательно' });
    const resInsert = db.prepare('INSERT INTO categories (name, parent_id) VALUES (?, ?)').run(name.trim(), parent_id ? Number(parent_id) : null);
    return res.status(201).json({ id: Number(resInsert.lastInsertRowid), name: name.trim() });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// 9. НАСТРОЙКИ (КУРС, СТАВКА ДОСТАВКИ ЗА КГ, WHATSAPP)
app.get('/api/settings', (_req, res) => {
  return res.json({
    whatsapp_phone: getSetting('whatsapp_phone', '992444431'),
    delivery_per_kg_tjs: getSetting('delivery_per_kg_tjs', '30'),
  });
});

app.get('/api/admin/settings', requireAdmin, (_req, res) => {
  return res.json({
    whatsapp_phone: getSetting('whatsapp_phone', '992444431'),
    delivery_per_kg_tjs: getSetting('delivery_per_kg_tjs', '30'),
    cny_tjs_rate: getSetting('cny_tjs_rate', '1.45'),
  });
});

app.post('/api/admin/settings', requireAdmin, (req, res) => {
  try {
    const { whatsapp_phone, delivery_per_kg_tjs, cny_tjs_rate } = req.body;
    if (whatsapp_phone) setSetting('whatsapp_phone', String(whatsapp_phone).trim());
    if (delivery_per_kg_tjs) setSetting('delivery_per_kg_tjs', String(delivery_per_kg_tjs).trim());
    if (cny_tjs_rate) setSetting('cny_tjs_rate', String(cny_tjs_rate).trim());

    // Пересчет цен всех вариантов в базе по новому курсу/доставке
    const allVariants = db.prepare('SELECT id, price_cny, weight_kg FROM product_variants').all() as Array<{ id: number; price_cny: number; weight_kg: number }>;
    const updateV = db.prepare('UPDATE product_variants SET price_tjs = ? WHERE id = ?');
    for (const v of allVariants) {
      const newTjs = calculateVariantPriceTjs(v.price_cny, v.weight_kg);
      updateV.run(newTjs, v.id);
    }

    return res.json({ success: true, message: 'Настройки сохранены и все цены вариантов пересчитаны' });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// 10. ТЕСТИРОВАНИЕ ИИ АНАЛИЗА ИЗ АДМИНКИ
app.post('/api/admin/test-gemini', requireAdmin, async (req, res) => {
  try {
    const { title, raw_text } = req.body;
    const textToAnalyze = raw_text || title || '2026新款夏季透气飞织运动鞋男鞋情侣款轻便减震跑步鞋 黑色 41 42 43 白色 41 42 43 价格 65元 重量0.75kg';
    const result = await analyzeProductWithGemini(textToAnalyze, title || 'Спортивная обувь');
    return res.json({ success: true, result });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Пинг-эндпоинт для Chrome-расширения
app.get('/api/ping', (_req, res) => {
  res.json({
    status: 'ok',
    service: 'M.Savdo Enterprise API',
    gemini_enabled: !!aiClient,
    time: new Date().toISOString()
  });
});

// Эндпоинт для получения свежего кода файлов расширения
app.get('/api/extension-file', (req, res) => {
  const file = String(req.query.file || 'content.js');
  const allowed = ['content.js', 'background.js', 'manifest.json', 'popup.html', 'popup.js', 'app.py'];
  if (!allowed.includes(file)) return res.status(400).send('Invalid file');
  const filePath = file === 'app.py' ? path.join(process.cwd(), 'app.py') : path.join(process.cwd(), 'chrome-extension', file);
  if (fs.existsSync(filePath)) {
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    return res.sendFile(filePath);
  }
  return res.status(404).send('Not found');
});

// ==========================================
// VITE DEV SERVER MIDDLEWARE
// ==========================================
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (_req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 M.Savdo E-Commerce Server запущен на http://localhost:${PORT}`);
  });
}

startServer();
