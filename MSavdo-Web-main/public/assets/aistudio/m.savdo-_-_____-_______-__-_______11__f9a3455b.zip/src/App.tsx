/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Product, Category, CartItem } from './types';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { RulesView } from './components/RulesView';
import { AdminPanel } from './components/AdminPanel';
import { ToastContainer, ToastItem } from './components/Toast';
import { 
  Search, 
  ShoppingBag, 
  Package, 
  Lock,
  X,
  MessageCircle,
  Home,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';

const BRAND_LOGO_URL = "/assets/aistudio/photo_2026-06-11_22-16-50_6464a600.jpg";

export default function App() {
  const [currentView, setCurrentView] = useState<'catalog' | 'rules' | 'admin'>('catalog');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Глобальная система всплывающих уведомлений (Toasts)
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const addToast = (type: 'success' | 'error' | 'warning' | 'info', title: string, message?: string) => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, type, title, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Данные каталога из API
  const [products, setProducts] = useState<Product[]>([]);
  const [categoriesTree, setCategoriesTree] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [whatsappPhone, setWhatsappPhone] = useState('992444431');

  // Фильтры и живой поиск
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | null>(null);
  const [deliveryFilter, setDeliveryFilter] = useState<'all' | 'stock' | 'order'>('all');
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Корзина на клиенте
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('msavdo_cart_v2');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('msavdo_cart_v2', JSON.stringify(cart));
    } catch {
      // Игнорируем ошибку квоты
    }
  }, [cart]);

  // Загрузка каталога с глобальным перехватом ошибок
  const fetchCatalog = async () => {
    setIsLoading(true);
    try {
      // 1. Товары
      const resProducts = await fetch('/api/products');
      if (!resProducts.ok) {
        throw new Error(`Ошибка сервера при получении каталога: HTTP ${resProducts.status}`);
      }
      const dataProducts = await resProducts.json();
      setProducts(dataProducts.products || []);

      // 2. Категории
      const resCategories = await fetch('/api/categories');
      if (resCategories.ok) {
        const dataCategories = await resCategories.json();
        setCategoriesTree(dataCategories.tree || dataCategories.categories || []);
      }

      // 3. Контакты
      const resSettings = await fetch('/api/settings');
      if (resSettings.ok) {
        const dataSettings = await resSettings.json();
        if (dataSettings.whatsapp_phone) {
          setWhatsappPhone(dataSettings.whatsapp_phone);
        }
      }
    } catch (err: any) {
      console.error('[M.Savdo] Ошибка сети при загрузке каталога:', err);
      addToast(
        'error',
        'Сбой синхронизации каталога',
        err.message || 'Не удалось получить актуальные товары. Проверьте интернет-соединение.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCatalog();

    // Проверка URL параметра для скрытого служебного входа (?admin=true)
    const params = new URLSearchParams(window.location.search);
    if (params.get('admin') === 'true' || params.get('manage') === '1') {
      setCurrentView('admin');
    }
  }, []);

  // Добавление в корзину конкретного варианта
  const handleAddToCart = (item: CartItem) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.id === item.id);
      if (existing) {
        return prev.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prev, item];
    });
    addToast('success', 'Товар добавлен в корзину', `${item.title} (${item.color}, ${item.size})`);
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveFromCart = (id: string) => {
    setCart((prev) => prev.filter((item) => item.id !== id));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Фильтрация товаров по поиску, категории и типу доставки
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      if (deliveryFilter === 'stock' && p.delivery_type !== 'stock') return false;
      if (deliveryFilter === 'order' && p.delivery_type === 'stock') return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const titleMatch = p.title.toLowerCase().includes(q);
        const skuMatch = p.base_sku.toLowerCase().includes(q);
        const descMatch = (p.description || '').toLowerCase().includes(q);
        if (!titleMatch && !skuMatch && !descMatch) return false;
      }

      if (selectedCategoryId !== null) {
        if (p.category_id === selectedCategoryId) return true;
        const rootCat = categoriesTree.find((c) => c.id === selectedCategoryId);
        if (rootCat && rootCat.subcategories) {
          const subIds = rootCat.subcategories.map((s) => s.id);
          if (p.category_id && subIds.includes(p.category_id)) return true;
        }
        return false;
      }

      return true;
    });
  }, [products, searchQuery, selectedCategoryId, deliveryFilter, categoriesTree]);

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col antialiased selection:bg-amber-400 selection:text-black font-sans pb-16 md:pb-0">
      
      {/* Глобальные UI-уведомления (Toasts) */}
      <ToastContainer toasts={toasts} onDismiss={removeToast} />

      {/* ======================================================== */}
      {/* 1. ШАПКА МАГАЗИНА: ЖЕЛТО-ЧЕРНЫЙ СТИЛЬ M.SAVDO */}
      {/* Строгая клиентская изоляция: никаких кнопок импорта или ссылок на Китай */}
      {/* ======================================================== */}
      <header className="sticky top-0 z-40 bg-black text-white border-b border-zinc-800 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 sm:h-18 flex items-center justify-between gap-4">
          
          {/* Бренд с официальным логотипом */}
          <div 
            onClick={() => {
              setCurrentView('catalog');
              setSelectedCategoryId(null);
              setSearchQuery('');
            }}
            className="cursor-pointer flex items-center gap-3 shrink-0 select-none group"
          >
            <div className="relative w-10 h-10 sm:w-11 sm:h-11 rounded-xl overflow-hidden border-2 border-amber-400 shadow-sm shrink-0 bg-amber-400 flex items-center justify-center">
              <img 
                src={BRAND_LOGO_URL} 
                alt="M.SAVDO" 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />
            </div>
            
            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <span className="text-xl sm:text-2xl font-black tracking-tight text-white font-heading">
                  M.<span className="text-amber-400">SAVDO</span>
                </span>
                <span className="bg-amber-400 text-black text-[9px] font-black px-1.5 py-0.5 rounded uppercase">
                  TJ
                </span>
              </div>
              <div className="text-[10px] text-zinc-400 font-medium hidden sm:flex items-center gap-1">
                <span>Каталог фабричных товаров</span>
                <span className="text-zinc-600">·</span>
                <a 
                  href="https://instagram.com/MSavdo.tj" 
                  target="_blank" 
                  rel="noreferrer"
                  onClick={(e) => e.stopPropagation()}
                  className="text-amber-400 hover:underline flex items-center gap-0.5"
                >
                  @MSavdo.tj
                </a>
              </div>
            </div>
          </div>

          {/* Навигация для клиентов */}
          <nav className="hidden md:flex items-center gap-6 text-xs sm:text-sm font-bold text-zinc-300">
            <button
              onClick={() => {
                setCurrentView('catalog');
                setSelectedCategoryId(null);
              }}
              className={`hover:text-amber-400 transition-colors whitespace-nowrap ${
                currentView === 'catalog' ? 'text-amber-400 font-extrabold' : ''
              }`}
            >
              Каталог
            </button>
            <button
              onClick={() => setCurrentView('rules')}
              className={`hover:text-amber-400 transition-colors whitespace-nowrap ${
                currentView === 'rules' ? 'text-amber-400 font-extrabold' : ''
              }`}
            >
              Правила сервиса и доставка
            </button>
            <a
              href="https://instagram.com/MSavdo.tj"
              target="_blank"
              rel="noreferrer"
              className="text-zinc-400 hover:text-amber-400 transition-colors whitespace-nowrap flex items-center gap-1"
            >
              <span>Instagram: @MSavdo.tj</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </nav>

          {/* Корзина заказа */}
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative inline-flex items-center gap-2 px-3.5 sm:px-4 py-2 sm:py-2.5 text-xs sm:text-sm font-black rounded-xl bg-amber-400 text-black hover:bg-amber-300 transition-all shadow-md active:scale-95"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline">Корзина</span>
              <span className="bg-black text-amber-400 text-xs font-mono font-extrabold rounded-full px-2 py-0.5 min-w-[20px] text-center">
                {totalCartCount}
              </span>
            </button>
          </div>

        </div>
      </header>

      {/* ======================================================== */}
      {/* 2. ОСНОВНОЙ КОНТЕНТ */}
      {/* ======================================================== */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-6">
        
        {/* ЭКРАН 1: ПРАВИЛА СЕРВИСА */}
        {currentView === 'rules' && (
          <RulesView
            onBack={() => setCurrentView('catalog')}
            onOpenCart={() => setIsCartOpen(true)}
          />
        )}

        {/* ЭКРАН 2: АДМИН-ПАНЕЛЬ (ТОЛЬКО ЗДЕСЬ ИМПОРТ И УПРАВЛЕНИЕ) */}
        {currentView === 'admin' && (
          <AdminPanel
            onBack={() => setCurrentView('catalog')}
            onRefreshCatalog={fetchCatalog}
          />
        )}

        {/* ЭКРАН 3: ПУБЛИЧНЫЙ КАТАЛОГ (КОМПАКТНЫЙ, БЫСТРЫЙ, МОБИЛЬНЫЙ) */}
        {currentView === 'catalog' && (
          <div className="space-y-4 sm:space-y-6">
            
            {/* Поисковая строка — прямо вверху без лишних баннеров */}
            <div className="relative max-w-3xl mx-auto">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                <Search className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Поиск по названию или артикулу (например: кроссовки, худи, MS-849)..."
                className="w-full pl-10 sm:pl-12 pr-10 py-3 sm:py-3.5 bg-white border border-slate-200 rounded-2xl text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-amber-400 shadow-xs transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Быстрые фильтры категорий (горизонтальный свайп на мобильных) */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none text-xs font-bold select-none py-1">
              <button
                onClick={() => setSelectedCategoryId(null)}
                className={`px-3.5 py-2 rounded-xl whitespace-nowrap transition-all shrink-0 ${
                  selectedCategoryId === null
                    ? 'bg-black text-amber-400 shadow-sm font-black'
                    : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                Все категории ({products.length})
              </button>

              {categoriesTree.map((cat) => {
                const isActive = selectedCategoryId === cat.id;
                return (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategoryId(cat.id)}
                    className={`px-3.5 py-2 rounded-xl whitespace-nowrap transition-all shrink-0 ${
                      isActive
                        ? 'bg-black text-amber-400 shadow-sm font-black'
                        : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                    }`}
                  >
                    {cat.name}
                  </button>
                );
              })}
            </div>

            {/* Быстрый фильтр типа доставки: Наличие в Душанбе / Под заказ */}
            <div className="flex flex-wrap items-center gap-2 text-xs font-bold pt-1">
              <button
                onClick={() => setDeliveryFilter('all')}
                className={`px-3 py-1.5 rounded-xl transition-all ${
                  deliveryFilter === 'all'
                    ? 'bg-zinc-900 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                Все товары ({products.length})
              </button>
              <button
                onClick={() => setDeliveryFilter('stock')}
                className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 ${
                  deliveryFilter === 'stock'
                    ? 'bg-emerald-600 text-white shadow-xs font-extrabold'
                    : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span>🚚 В наличии в Душанбе (1 день)</span>
              </button>
              <button
                onClick={() => setDeliveryFilter('order')}
                className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 ${
                  deliveryFilter === 'order'
                    ? 'bg-amber-400 text-black shadow-xs font-black border border-amber-500'
                    : 'bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-200'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                <span>⏳ Под заказ (15-30 дней)</span>
              </button>
            </div>

            {/* СЕТКА ТОВАРОВ: 2 КОЛОНКИ НА СМАРТФОНАХ (ЧЕТКО И КРАСИВО) */}
            <section>
              {isLoading ? (
                <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-6">
                  {[...Array(6)].map((_, i) => (
                    <div key={i} className="bg-white rounded-2xl p-3 border border-slate-200 animate-pulse space-y-3">
                      <div className="aspect-square bg-slate-200 rounded-xl" />
                      <div className="h-4 bg-slate-200 rounded w-3/4" />
                      <div className="h-3 bg-slate-100 rounded w-1/2" />
                    </div>
                  ))}
                </div>
              ) : filteredProducts.length === 0 ? (
                <div className="bg-white border border-slate-200 rounded-3xl p-8 sm:p-12 text-center space-y-3 shadow-xs max-w-lg mx-auto my-6">
                  <Package className="w-10 h-10 text-amber-500 mx-auto" />
                  <h3 className="text-sm sm:text-base font-bold text-slate-900">
                    Товары не найдены
                  </h3>
                  <p className="text-xs text-slate-400">
                    Попробуйте изменить поисковый запрос или выберите другую категорию.
                  </p>
                  <button
                    onClick={() => {
                      setSelectedCategoryId(null);
                      setSearchQuery('');
                    }}
                    className="mt-2 px-4 py-2 bg-black text-amber-400 rounded-xl text-xs font-bold hover:bg-zinc-800 transition-colors"
                  >
                    Показать весь каталог
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-6">
                  {filteredProducts.map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      onSelect={(p) => setSelectedProduct(p)}
                      onAddToCart={() => setSelectedProduct(product)}
                    />
                  ))}
                </div>
              )}
            </section>

          </div>
        )}

      </main>

      {/* ======================================================== */}
      {/* 3. МОДАЛЬНЫЕ ОКНА */}
      {/* ======================================================== */}
      
      {/* Карточка товара */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
      />

      {/* Корзина */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveFromCart}
        onClearCart={handleClearCart}
        onOpenRules={() => {
          setIsCartOpen(false);
          setCurrentView('rules');
        }}
        whatsappPhone={whatsappPhone}
      />

      {/* ======================================================== */}
      {/* 4. МОБИЛЬНАЯ НИЖНЯЯ ПАНЕЛЬ НАВИГАЦИИ (ФИКСИРОВАННАЯ) */}
      {/* ======================================================== */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-black text-white border-t border-zinc-800 px-4 py-2 flex items-center justify-around shadow-2xl">
        <button
          onClick={() => {
            setCurrentView('catalog');
            setSelectedCategoryId(null);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center gap-1 ${currentView === 'catalog' ? 'text-amber-400' : 'text-zinc-400'}`}
        >
          <Home className="w-4 h-4" />
          <span className="text-[10px] font-bold">Каталог</span>
        </button>

        <button
          onClick={() => {
            setCurrentView('catalog');
            searchInputRef.current?.focus();
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="flex flex-col items-center gap-1 text-zinc-400"
        >
          <Search className="w-4 h-4" />
          <span className="text-[10px] font-bold">Поиск</span>
        </button>

        <a
          href={`https://wa.me/${whatsappPhone.replace(/[^0-9]/g, '')}`}
          target="_blank"
          rel="noreferrer"
          className="flex flex-col items-center gap-1 text-emerald-400"
        >
          <MessageCircle className="w-4 h-4" />
          <span className="text-[10px] font-bold">WhatsApp</span>
        </a>

        <button
          onClick={() => setIsCartOpen(true)}
          className="relative flex flex-col items-center gap-1 text-amber-400 font-bold"
        >
          <div className="relative">
            <ShoppingBag className="w-4 h-4" />
            {totalCartCount > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-amber-400 text-black text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center">
                {totalCartCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-bold">Корзина</span>
        </button>
      </div>

      {/* ======================================================== */}
      {/* 5. ФУТЕР (ПРЕМИАЛЬНЫЙ ЖЕЛТО-ЧЕРНЫЙ БРЕНДИНГ + СКРЫТЫЙ СЛУЖЕБНЫЙ ВХОД) */}
      {/* ======================================================== */}
      <footer className="bg-black text-white border-t border-zinc-800 mt-16 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-400">
          
          <div className="flex items-center gap-3">
            <img 
              src={BRAND_LOGO_URL} 
              alt="M.Savdo" 
              className="w-7 h-7 rounded-lg object-cover border border-amber-400"
            />
            <div>
              <span className="font-black text-white">M.SAVDO</span> · Международный сервис выкупа фабричных товаров
              <span className="text-zinc-600 block sm:inline sm:ml-2">Instagram: <strong className="text-amber-400">@MSavdo.tj</strong></span>
            </div>
          </div>

          <div className="flex items-center gap-5">
            <button 
              onClick={() => setCurrentView('rules')} 
              className="hover:text-amber-400 transition-colors"
            >
              Правила сервиса
            </button>
            <a 
              href="https://instagram.com/MSavdo.tj" 
              target="_blank" 
              rel="noreferrer"
              className="text-amber-400 hover:underline"
            >
              @MSavdo.tj
            </a>
            
            {/* Скрытый дискретный служебный вход: только для владельца магазина */}
            <button 
              onClick={() => setCurrentView('admin')} 
              className="text-zinc-600 hover:text-zinc-400 transition-colors p-1"
              title="Панель владельца"
            >
              <Lock className="w-3.5 h-3.5" />
            </button>
          </div>

        </div>
      </footer>

    </div>
  );
}
