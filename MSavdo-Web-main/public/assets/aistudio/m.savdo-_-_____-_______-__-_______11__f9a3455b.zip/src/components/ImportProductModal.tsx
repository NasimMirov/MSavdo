import React, { useState } from 'react';
import { X, Sparkles, Link, Clipboard, Check, AlertCircle, ArrowRight, Package } from 'lucide-react';

interface ImportProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const ImportProductModal: React.FC<ImportProductModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [activeTab, setActiveTab] = useState<'link' | 'json'>('link');
  const [productLink, setProductLink] = useState('');
  const [jsonText, setJsonText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  if (!isOpen) return null;

  const demoPresets = [
    {
      label: 'Чернила Epson 004 (6 вариантов, видео 1688)',
      link: 'https://detail.1688.com/offer/798257023213.html',
      title: 'Комплект оригинальных совместимых чернил для струйных принтеров Epson 004 (L3169 / L3108 / L3115 / L3118)',
      priceCny: 3.14,
      weight: 0.35,
      images: [
        'https://cbu01.alicdn.com/img/ibank/O1CN016f40P622jV0Z2x8r8_!!2200742183570-0-cib.jpg',
        'https://cbu01.alicdn.com/img/ibank/O1CN01OflO7p22jV0V1m2y9_!!2200742183570-0-cib.jpg'
      ],
      videoUrl: 'https://cloud.video.taobao.com/play/u/2200742183570/p/1/e/6/t/1/460775369680.mp4',
      variants: [
        { color: 'Черный 70 мл (Dye)', size: '70 мл', price_cny: 3.39, stock: 49000, weight_kg: 0.1 },
        { color: 'Синий 70 мл (Cyan)', size: '70 мл', price_cny: 3.39, stock: 49000, weight_kg: 0.1 },
        { color: 'Красный 70 мл (Magenta)', size: '70 мл', price_cny: 3.39, stock: 49000, weight_kg: 0.1 },
        { color: 'Желтый 70 мл (Yellow)', size: '70 мл', price_cny: 3.39, stock: 49000, weight_kg: 0.1 },
        { color: 'Черный 127 мл (Pigment)', size: '127 мл', price_cny: 12.88, stock: 49000, weight_kg: 0.18 },
        { color: 'Черный 127 мл (Dye)', size: '127 мл', price_cny: 5.98, stock: 49000, weight_kg: 0.18 }
      ]
    },
    {
      label: 'Мужские рабочие туфли из экокожи (размеры 39-44)',
      link: 'https://detail.1688.com/offer/923047260456.html',
      title: 'Мужские дышащие рабочие туфли из экокожи на 100% толстой подошве (антискольжение, защита от запаха)',
      priceCny: 9.50,
      weight: 0.75,
      images: [
        'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800',
        'https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=800'
      ],
      videoUrl: '',
      variants: [
        { color: 'Кофейный коричневый', size: '39', price_cny: 9.50, stock: 692, weight_kg: 0.75 },
        { color: 'Кофейный коричневый', size: '40', price_cny: 9.50, stock: 746, weight_kg: 0.75 },
        { color: 'Кофейный коричневый', size: '41', price_cny: 9.50, stock: 613, weight_kg: 0.75 },
        { color: 'Графитовый серый', size: '40', price_cny: 9.50, stock: 500, weight_kg: 0.75 },
        { color: 'Классический черный', size: '41', price_cny: 9.50, stock: 500, weight_kg: 0.75 }
      ]
    }
  ];

  const handleImportLink = async (preset?: typeof demoPresets[0]) => {
    setIsLoading(true);
    setErrorMsg('');
    setSuccessMsg('');

    try {
      let payload: any;
      if (preset) {
        payload = {
          title: preset.title,
          original_link: preset.link,
          price_cny: preset.priceCny,
          weight_kg: preset.weight,
          images: preset.images.join(','),
          video_url: preset.videoUrl,
          variants: preset.variants,
          status: 'active'
        };
      } else {
        const link = productLink.trim();
        if (!link) {
          throw new Error('Пожалуйста, введите ссылку на товар 1688 или Pinduoduo');
        }

        // Автоматическое определение по ссылке или названию
        payload = {
          title: 'Товар из каталога 1688',
          original_link: link,
          raw_text: link,
          price_cny: 35.0,
          weight_kg: 0.5,
          images: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800',
          status: 'active'
        };
      }

      const res = await fetch('/api/add-product', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (res.ok && data.status === 'success') {
        setSuccessMsg(`✓ Товар «${data.product?.title || payload.title}» успешно импортирован в каталог M.Savdo!`);
        setTimeout(() => {
          onSuccess();
          onClose();
        }, 1800);
      } else {
        throw new Error(data.message || data.error || 'Ошибка при импорте товара');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Сбой сети');
    } finally {
      setIsLoading(false);
    }
  };

  const handleImportJson = async () => {
    setIsLoading(true);
    setErrorMsg('');
    setSuccessMsg('');

    try {
      if (!jsonText.trim()) {
        throw new Error('Вставьте скопированный JSON из расширения');
      }

      let parsed: any;
      try {
        parsed = JSON.parse(jsonText);
      } catch (e) {
        throw new Error('Некорректный формат JSON. Убедитесь, что скопировали данные полностью.');
      }

      const res = await fetch('/api/add-product', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(parsed)
      });

      const data = await res.json();
      if (res.ok && data.status === 'success') {
        setSuccessMsg(`✓ Товар «${data.product?.title || parsed.title}» успешно сохранен!`);
        setTimeout(() => {
          onSuccess();
          onClose();
        }, 1800);
      } else {
        throw new Error(data.message || data.error || 'Ошибка импорта JSON');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Ошибка обработки JSON');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-hidden shadow-2xl border border-slate-200 flex flex-col">
        
        {/* Заголовок */}
        <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Прямой импорт товара в M.Savdo
              </h2>
              <p className="text-xs text-slate-500">
                Без необходимости настройки портов Chrome-расширения
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Вкладки */}
        <div className="border-b border-slate-200 px-6 pt-3 flex gap-4 text-xs font-bold bg-white">
          <button
            onClick={() => setActiveTab('link')}
            className={`pb-2.5 flex items-center gap-1.5 border-b-2 transition-colors ${
              activeTab === 'link'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Link className="w-4 h-4" />
            <span>По ссылке 1688 / Готовым товарам</span>
          </button>
          <button
            onClick={() => setActiveTab('json')}
            className={`pb-2.5 flex items-center gap-1.5 border-b-2 transition-colors ${
              activeTab === 'json'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Clipboard className="w-4 h-4" />
            <span>Вставить JSON из расширения</span>
          </button>
        </div>

        {/* Контент */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs">
          
          {errorMsg && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <div>{errorMsg}</div>
            </div>
          )}

          {successMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 flex items-start gap-2 font-semibold">
              <Check className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" />
              <div>{successMsg}</div>
            </div>
          )}

          {activeTab === 'link' ? (
            <div className="space-y-4">
              <div>
                <label className="block font-bold text-slate-700 mb-1.5">
                  Вставьте ссылку на товар с 1688.com или Pinduoduo:
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={productLink}
                    onChange={(e) => setProductLink(e.target.value)}
                    placeholder="https://detail.1688.com/offer/798257023213.html"
                    className="flex-1 px-3.5 py-2.5 border border-slate-300 rounded-xl font-mono text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                  <button
                    onClick={() => handleImportLink()}
                    disabled={isLoading}
                    className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition-colors disabled:opacity-50 flex items-center gap-1.5"
                  >
                    <span>{isLoading ? 'Импорт...' : 'Импортировать'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="pt-2">
                <div className="font-bold text-slate-800 mb-2 flex items-center gap-1.5">
                  <Package className="w-4 h-4 text-emerald-600" />
                  <span>Или добавьте протестированные реальные товары из 1688 в 1 клик:</span>
                </div>
                <div className="space-y-2">
                  {demoPresets.map((preset, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-slate-50 hover:bg-emerald-50/60 border border-slate-200 hover:border-emerald-300 rounded-2xl flex items-center justify-between gap-3 transition-colors"
                    >
                      <div>
                        <div className="font-bold text-slate-900 text-xs">
                          {preset.label}
                        </div>
                        <div className="text-[11px] text-slate-500 truncate max-w-md mt-0.5">
                          {preset.link}
                        </div>
                      </div>
                      <button
                        onClick={() => handleImportLink(preset)}
                        disabled={isLoading}
                        className="px-3 py-1.5 bg-slate-900 hover:bg-emerald-700 text-white rounded-lg font-bold text-[11px] transition-colors shrink-0"
                      >
                        {isLoading ? 'Загрузка...' : '+ Добавить'}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1.5">
                  Вставьте JSON, скопированный по кнопке «📋 Скопировать JSON» в расширении:
                </label>
                <textarea
                  value={jsonText}
                  onChange={(e) => setJsonText(e.target.value)}
                  rows={8}
                  placeholder={`{\n  "title": "Чернила Epson 004",\n  "price_cny": 3.14,\n  "variants": [...]\n}`}
                  className="w-full p-3 font-mono text-[11px] border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-slate-950 text-slate-100"
                />
              </div>
              <button
                onClick={handleImportJson}
                disabled={isLoading}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition-colors disabled:opacity-50 flex items-center justify-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>{isLoading ? 'Сохранение товара...' : 'Импортировать в M.Savdo'}</span>
              </button>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
