import React, { useState } from 'react';
import { CartItem } from '../types';
import { X, Trash2, Plus, Minus, Send, ShoppingBag, ShieldAlert, Check, Clock, Truck } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
  onOpenRules: () => void;
  whatsappPhone?: string;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onOpenRules,
  whatsappPhone = '992444431',
}) => {
  const [agreedWithRules, setAgreedWithRules] = useState(false);

  if (!isOpen) return null;

  const totalSum = items.reduce((sum, item) => sum + item.price_tjs * item.quantity, 0);

  // Формирование текста заказа в WhatsApp строго с указанием Названия, Цвета, Размера, Артикула SKU и цены в TJS
  const handleWhatsAppCheckout = () => {
    if (!agreedWithRules || items.length === 0) return;

    const itemsText = items.map((item, index) => {
      const lineTotal = item.price_tjs * item.quantity;
      return [
        `📦 Позиция #${index + 1}:`,
        `• Товар: ${item.title}`,
        `• Артикул: ${item.variant_sku}`,
        `• Цвет: ${item.color || 'Стандарт'}`,
        `• Размер: ${item.size || 'One Size'}`,
        `• Количество: ${item.quantity} шт.`,
        `• Цена: ${item.price_tjs} TJS (Сумма: ${lineTotal} TJS)`
      ].join('\n');
    }).join('\n\n');

    const message = [
      `Здравствуйте! Хочу оформить заказ в магазине M.Savdo (@MSavdo.tj):`,
      ``,
      itemsText,
      ``,
      `💰 ИТОГО К ОПЛАТЕ: ${totalSum} TJS`,
      `🚚 Срок доставки: под заказ 15–30 дней напрямую с фабрики`,
      `✓ С правилами сервиса (возврат строго на карту плательщика) ознакомлен и согласен.`
    ].join('\n');

    const cleanPhone = whatsappPhone.replace(/[^0-9]/g, '');
    const waUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
    window.location.href = waUrl;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white border-l border-slate-200 shadow-2xl flex flex-col justify-between">
          
          {/* Заголовок корзины */}
          <div className="p-5 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-emerald-700" />
              <h2 className="text-lg font-bold text-slate-900 font-heading">
                Корзина покупок
              </h2>
              <span className="text-xs text-slate-500 font-mono">({items.length})</span>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg transition-colors"
              aria-label="Закрыть корзину"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Список товаров */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {items.length === 0 ? (
              <div className="py-20 text-center text-slate-400 space-y-3">
                <ShoppingBag className="w-12 h-12 mx-auto text-slate-200" />
                <p className="text-sm font-semibold text-slate-700">В корзине пока пусто</p>
                <p className="text-xs text-slate-400 max-w-xs mx-auto">
                  Выберите понравившийся товар в каталоге, укажите нужный цвет и размер.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {items.map((item) => (
                  <div key={item.id} className="py-4 flex items-start gap-3">
                    <img
                      src={item.image || 'https://placehold.co/100x100?text=M.Savdo'}
                      alt={item.title}
                      referrerPolicy="no-referrer"
                      className="w-16 h-18 rounded-xl object-cover border border-slate-200 shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-[10px] font-mono font-bold text-slate-400">
                        {item.variant_sku}
                      </div>
                      <h4 className="text-xs font-bold text-slate-900 line-clamp-1 leading-snug">
                        {item.title}
                      </h4>

                      {/* Параметры варианта: Цвет и Размер */}
                      <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-1 font-medium">
                        {item.color && item.color !== 'Стандарт' && (
                          <span className="text-slate-700">Цвет: <strong>{item.color}</strong></span>
                        )}
                        {item.color && item.color !== 'Стандарт' && item.size && item.size !== 'One Size' && (
                          <span className="text-slate-300">·</span>
                        )}
                        {item.size && item.size !== 'One Size' && (
                          <span className="text-slate-700">Разм: <strong>{item.size}</strong></span>
                        )}
                      </div>

                      <div className="text-xs font-mono font-bold text-emerald-800 mt-1.5">
                        {item.price_tjs} TJS
                      </div>

                      {/* Управление количеством */}
                      <div className="flex items-center justify-between mt-2.5">
                        <div className="flex items-center border border-slate-200 rounded-lg bg-slate-50">
                          <button
                            onClick={() => onUpdateQuantity(item.id, -1)}
                            className="p-1 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-l transition-colors"
                            title="Уменьшить"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-3 text-xs font-mono font-semibold text-slate-800">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(item.id, 1)}
                            className="p-1 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-r transition-colors"
                            title="Увеличить"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono font-bold text-slate-900">
                            {item.price_tjs * item.quantity} TJS
                          </span>
                          <button
                            onClick={() => onRemoveItem(item.id)}
                            className="text-slate-400 hover:text-red-600 transition-colors p-1"
                            title="Удалить"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Нижний блок с подтверждением и кнопкой WhatsApp */}
          {items.length > 0 && (
            <div className="p-5 border-t border-slate-200 bg-slate-50/80 space-y-4">
              <div className="flex items-center justify-between text-base font-bold text-slate-900">
                <span>Итого к оплате:</span>
                <span className="text-2xl font-mono text-emerald-800">{totalSum} TJS</span>
              </div>

              {/* Авторитетный инфо-блок срока доставки */}
              <div className="p-3 bg-amber-50/90 border border-amber-200/90 rounded-xl flex items-center gap-2.5 text-xs text-slate-800 shadow-xs">
                <Truck className="w-4 h-4 text-amber-600 shrink-0" />
                <span><strong>🚚 Срок доставки:</strong> под заказ 15–30 дней напрямую с фабрики</span>
              </div>

              {/* ОБЯЗАТЕЛЬНЫЙ ЧЕКБОКС: БЕЗ НЕГО ЗАКАЗ ЗАБЛОКИРОВАН */}
              <div className="p-3.5 bg-amber-50/80 border border-amber-200 rounded-xl space-y-2">
                <label className="flex items-start gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={agreedWithRules}
                    onChange={(e) => setAgreedWithRules(e.target.checked)}
                    className="mt-0.5 w-4 h-4 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500 cursor-pointer"
                  />
                  <span className="text-[11px] text-slate-800 leading-tight">
                    Я ознакомлен и согласен с{' '}
                    <button
                      type="button"
                      onClick={onOpenRules}
                      className="text-emerald-700 underline font-semibold hover:text-emerald-800"
                    >
                      Правилами сервиса M.Savdo
                    </button>{' '}
                    (включая пункт 6: возврат строго на карту плательщика).
                  </span>
                </label>

                {!agreedWithRules && (
                  <div className="flex items-center gap-1.5 text-[10px] text-amber-800 font-medium">
                    <ShieldAlert className="w-3 h-3 text-amber-600 shrink-0" />
                    <span>Отметьте согласие для активации кнопки заказа</span>
                  </div>
                )}
              </div>

              {/* КНОПКА ЗАКАЗА В WHATSAPP */}
              <button
                disabled={!agreedWithRules}
                onClick={handleWhatsAppCheckout}
                className={`w-full py-4 px-4 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-sm ${
                  agreedWithRules
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer hover:shadow'
                    : 'bg-slate-300 text-slate-500 cursor-not-allowed opacity-80'
                }`}
              >
                <Send className="w-4 h-4" />
                <span>Оформить заказ в WhatsApp</span>
              </button>

              <div className="flex justify-between items-center text-[10px] text-slate-400">
                <span>Менеджер: +{whatsappPhone}</span>
                <button
                  onClick={onClearCart}
                  className="hover:text-red-600 transition-colors"
                >
                  Очистить корзину
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
