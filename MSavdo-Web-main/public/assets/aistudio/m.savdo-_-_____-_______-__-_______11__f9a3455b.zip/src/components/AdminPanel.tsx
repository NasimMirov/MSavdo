import React, { useState, useEffect } from 'react';
import { Product, ProductVariant, Category } from '../types';
import { 
  AlertTriangle, 
  Lock, 
  Unlock, 
  LogOut, 
  ExternalLink, 
  Edit3, 
  Trash2, 
  RefreshCw, 
  Sparkles, 
  Scale, 
  Settings, 
  Layers, 
  ArrowLeft,
  Check,
  Save,
  Plus,
  FileCode,
  DollarSign,
  Truck,
  Clock,
  Video
} from 'lucide-react';
import { ImportProductModal } from './ImportProductModal';
import { ExportCodeModal } from './ExportCodeModal';

interface AdminPanelProps {
  onBack: () => void;
  onRefreshCatalog: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  onBack,
  onRefreshCatalog,
}) => {
  // Авторизация
  const [authToken, setAuthToken] = useState<string | null>(() => {
    return localStorage.getItem('msavdo_admin_token');
  });
  const [loginUsername, setLoginUsername] = useState('admin');
  const [loginPassword, setLoginPassword] = useState('admin123');
  const [loginError, setLoginError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Состояния админки
  const [activeTab, setActiveTab] = useState<'products' | 'gemini_ai' | 'settings'>('products');
  const [adminProducts, setAdminProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any | null>(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);

  // Настройки ценообразования и логистики
  const [settings, setSettings] = useState({
    whatsapp_phone: '992444431',
    cny_tjs_rate: '1.45',
    delivery_per_kg_tjs: '30',
  });
  const [settingsSaved, setSettingsSaved] = useState(false);

  // Gemini AI тестер
  const [geminiTestInput, setGeminiTestInput] = useState('2026跨境新款夏季透气飞织运动鞋男鞋情侣款轻便减震跑步鞋');
  const [geminiResult, setGeminiResult] = useState<any>(null);
  const [isGeminiTesting, setIsGeminiTesting] = useState(false);

  // Проверка сессии при загрузке
  useEffect(() => {
    if (authToken) {
      loadAdminData();
    }
  }, [authToken]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggingIn(true);
    setLoginError('');

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: loginUsername, password: loginPassword }),
      });
      const data = await res.json();

      if (res.ok && data.token) {
        setAuthToken(data.token);
        localStorage.setItem('msavdo_admin_token', data.token);
      } else {
        setLoginError(data.error || 'Ошибка входа');
      }
    } catch (err: any) {
      setLoginError(err.message || 'Ошибка сети');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = () => {
    if (authToken) {
      fetch('/api/admin/logout', {
        method: 'POST',
        headers: { Authorization: `Bearer ${authToken}` },
      }).catch(() => {});
    }
    setAuthToken(null);
    localStorage.removeItem('msavdo_admin_token');
  };

  const loadAdminData = async () => {
    if (!authToken) return;
    setIsLoading(true);
    try {
      // Загрузка товаров с конфиденциальными полями (CNY, оригинальные ссылки, вес)
      const resProd = await fetch('/api/admin/products', {
        headers: { Authorization: `Bearer ${authToken}` },
      });
      if (resProd.status === 401) {
        handleLogout();
        return;
      }
      const prodData = await resProd.json();
      setAdminProducts(prodData.products || []);

      // Настройки
      const resSet = await fetch('/api/admin/settings', {
        headers: { Authorization: `Bearer ${authToken}` },
      });
      if (resSet.ok) {
        const setData = await resSet.json();
        setSettings({
          whatsapp_phone: setData.whatsapp_phone || '992444431',
          cny_tjs_rate: setData.cny_tjs_rate || '1.45',
          delivery_per_kg_tjs: setData.delivery_per_kg_tjs || '30',
        });
      }

      // Категории
      const resCat = await fetch('/api/categories');
      if (resCat.ok) {
        const catData = await resCat.json();
        setCategories(catData.tree || []);
      }
    } catch (err) {
      console.error('Ошибка загрузки данных админки:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authToken) return;

    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify(settings),
      });
      if (res.ok) {
        setSettingsSaved(true);
        setTimeout(() => setSettingsSaved(false), 2500);
        loadAdminData();
        onRefreshCatalog();
      }
    } catch (err) {
      console.error('Ошибка сохранения настроек:', err);
    }
  };

  const [newImageUrl, setNewImageUrl] = useState('');
  const [isSavingProduct, setIsSavingProduct] = useState(false);
  const [productSaveError, setProductSaveError] = useState('');

  const handleOpenCreateModal = () => {
    setProductSaveError('');
    setNewImageUrl('');
    setEditingProduct({
      id: 0,
      base_sku: 'MS-НОВЫЙ',
      title: '',
      description: '',
      delivery_type: 'order',
      status: 'active',
      category_id: null,
      category_name: 'Определится через ИИ Gemini 3.8 Flash',
      main_image: '',
      images: [],
      video_url: '',
      variants: [
        {
          color: 'Основной',
          size: 'Стандарт',
          price_tjs: 120,
          price_cny: 0,
          stock: 15,
          weight_kg: 0.5,
          image_url: '',
        },
      ],
    });
  };

  const handleOpenEditModal = (p: any) => {
    setProductSaveError('');
    setNewImageUrl('');
    let imgList: string[] = [];
    if (Array.isArray(p.images)) {
      imgList = p.images;
    } else if (typeof p.images === 'string' && p.images.trim()) {
      imgList = p.images.split(',').map((s: string) => s.trim()).filter(Boolean);
    } else if (p.main_image) {
      imgList = [p.main_image];
    }

    const varList = (p.variants || []).map((v: any) => ({
      id: v.id,
      color: v.color || 'Основной',
      size: v.size || 'Стандарт',
      price_tjs: v.price_tjs || 0,
      price_cny: v.price_cny || 0,
      stock: v.stock !== undefined ? v.stock : 10,
      weight_kg: v.weight_kg || 0.5,
      variant_sku: v.variant_sku || '',
      image_url: v.image_url || '',
    }));

    if (varList.length === 0) {
      varList.push({
        color: 'Основной',
        size: 'Стандарт',
        price_tjs: 100,
        price_cny: 0,
        stock: 10,
        weight_kg: 0.5,
        image_url: '',
      });
    }

    setEditingProduct({
      id: p.id,
      base_sku: p.base_sku,
      title: p.title,
      description: p.description || '',
      delivery_type: p.delivery_type || 'order',
      status: p.status || 'active',
      category_id: p.category_id,
      category_name: p.category_name || 'Мужская коллекция',
      main_image: p.main_image || imgList[0] || '',
      images: imgList,
      video_url: p.video_url || '',
      default_weight_kg: varList[0]?.weight_kg || 0.5,
      variants: varList,
    });
  };

  const handleAddGalleryImage = () => {
    if (!newImageUrl.trim() || !editingProduct) return;
    const cleanUrl = newImageUrl.trim();
    const curImgs = editingProduct.images || [];
    if (!curImgs.includes(cleanUrl)) {
      const updated = [...curImgs, cleanUrl];
      setEditingProduct({
        ...editingProduct,
        images: updated,
        main_image: editingProduct.main_image || cleanUrl,
      });
    }
    setNewImageUrl('');
  };

  const handleRemoveGalleryImage = (index: number) => {
    if (!editingProduct) return;
    const curImgs = [...(editingProduct.images || [])];
    const removed = curImgs.splice(index, 1)[0];
    let newMain = editingProduct.main_image;
    if (newMain === removed) {
      newMain = curImgs[0] || '';
    }
    setEditingProduct({
      ...editingProduct,
      images: curImgs,
      main_image: newMain,
    });
  };

  const handleAddVariantRow = () => {
    if (!editingProduct) return;
    const curVars = [...(editingProduct.variants || [])];
    curVars.push({
      color: '',
      size: 'Стандарт',
      price_tjs: 120,
      price_cny: 0,
      stock: 15,
      weight_kg: 0.5,
      image_url: editingProduct.main_image || '',
    });
    setEditingProduct({ ...editingProduct, variants: curVars });
  };

  const handleRemoveVariantRow = (index: number) => {
    if (!editingProduct || (editingProduct.variants || []).length <= 1) return;
    const curVars = [...(editingProduct.variants || [])];
    curVars.splice(index, 1);
    setEditingProduct({ ...editingProduct, variants: curVars });
  };

  const handleUpdateVariantField = (index: number, field: string, val: any) => {
    if (!editingProduct) return;
    const curVars = [...(editingProduct.variants || [])];
    curVars[index] = { ...curVars[index], [field]: val };
    setEditingProduct({ ...editingProduct, variants: curVars });
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authToken || !editingProduct) return;
    if (!editingProduct.title.trim()) {
      setProductSaveError('Укажите название товара');
      return;
    }

    setIsSavingProduct(true);
    setProductSaveError('');

    try {
      const payload = {
        title: editingProduct.title.trim(),
        description: editingProduct.description || '',
        delivery_type: editingProduct.delivery_type || 'order',
        status: editingProduct.status || 'active',
        main_image: editingProduct.main_image || (editingProduct.images?.[0] || ''),
        images: editingProduct.images || [],
        video_url: editingProduct.video_url || '',
        youtube_url: editingProduct.video_url || '',
        default_weight_kg: editingProduct.default_weight_kg || 0.5,
        variants: editingProduct.variants || [],
      };

      const url = editingProduct.id === 0 ? '/api/admin/products' : `/api/admin/products/${editingProduct.id}`;
      const method = editingProduct.id === 0 ? 'POST' : 'PUT';

      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Ошибка при сохранении товара');
      }

      setEditingProduct(null);
      await loadAdminData();
      onRefreshCatalog();
    } catch (err: any) {
      console.error('Ошибка сохранения товара:', err);
      setProductSaveError(err.message || 'Ошибка сети');
    } finally {
      setIsSavingProduct(false);
    }
  };

  const handleDeleteProduct = async (id: number) => {
    if (!authToken || !confirm('Удалить этот товар и все его модификации из базы?')) return;
    try {
      const res = await fetch(`/api/admin/products/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${authToken}` },
      });
      if (res.ok) {
        loadAdminData();
        onRefreshCatalog();
      }
    } catch (err) {
      console.error('Ошибка удаления:', err);
    }
  };

  const handleTestGemini = async () => {
    if (!authToken || !geminiTestInput.trim()) return;
    setIsGeminiTesting(true);
    setGeminiResult(null);

    try {
      const res = await fetch('/api/admin/test-gemini', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify({ title: geminiTestInput }),
      });
      const data = await res.json();
      setGeminiResult(data.result);
    } catch (err: any) {
      setGeminiResult({ error: err.message });
    } finally {
      setIsGeminiTesting(false);
    }
  };

  // ==========================================
  // ЭКРАН ВХОДА (ЕСЛИ НЕ АВТОРИЗОВАН)
  // ==========================================
  if (!authToken) {
    return (
      <div className="max-w-md mx-auto py-16 px-4">
        <div className="mb-6">
          <button
            onClick={onBack}
            className="inline-flex items-center gap-2 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Вернуться в публичный каталог</span>
          </button>
        </div>

        <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-xl space-y-6">
          <div className="text-center space-y-2">
            <div className="w-12 h-12 bg-slate-900 text-white rounded-2xl flex items-center justify-center mx-auto shadow-md">
              <Lock className="w-6 h-6 text-emerald-400" />
            </div>
            <h2 className="text-xl font-extrabold text-slate-900 font-heading">
              Служебный вход в M.Savdo
            </h2>
            <p className="text-xs text-slate-500">
              Доступ строго для владельца магазина. Конфиденциальные данные поставщиков и логистика.
            </p>
          </div>

          {loginError && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs font-semibold text-red-700 text-center">
              {loginError}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Логин администратора</label>
              <input
                type="text"
                required
                value={loginUsername}
                onChange={(e) => setLoginUsername(e.target.value)}
                className="w-full p-3 bg-slate-50 border border-slate-300 rounded-xl text-sm font-semibold text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Пароль доступа</label>
              <input
                type="password"
                required
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                className="w-full p-3 bg-slate-50 border border-slate-300 rounded-xl text-sm font-semibold text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={isLoggingIn}
              className="w-full py-3.5 bg-slate-900 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs uppercase tracking-wider transition-colors shadow-sm disabled:opacity-50"
            >
              {isLoggingIn ? 'Проверка...' : 'Войти в панель управления'}
            </button>

            <div className="p-3 bg-slate-50 rounded-xl text-[11px] text-slate-400 text-center border border-slate-100">
              Логин по умолчанию: <strong className="text-slate-700">admin</strong> / пароль: <strong className="text-slate-700">admin123</strong>
            </div>
          </form>
        </div>
      </div>
    );
  }

  // ==========================================
  // АВТОРИЗОВАННАЯ ПАНЕЛЬ УПРАВЛЕНИЯ
  // ==========================================
  return (
    <div className="max-w-7xl mx-auto py-4 space-y-6">
      
      {/* Верхняя полоса навигации админки */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 text-slate-500 hover:text-slate-900 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors"
            title="Вернуться на витрину"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          
          <img 
            src="/assets/aistudio/photo_2026-06-11_22-16-50_6464a600.jpg" 
            alt="M.Savdo" 
            className="w-10 h-10 rounded-xl object-cover border-2 border-amber-400 shadow-xs"
          />

          <div>
            <h1 className="text-lg sm:text-xl font-extrabold text-slate-900 font-heading flex items-center gap-2">
              <span>Панель управления M.SAVDO</span>
              <span className="text-[10px] font-mono bg-black text-amber-400 px-2 py-0.5 rounded-full font-black border border-amber-400/40">
                Владелец (@MSavdo.tj)
              </span>
            </h1>
            <p className="text-xs text-slate-400">
              ИИ-Бухгалтерия, расчет чистой прибыли, импорт товаров и Chrome-расширение
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsExportModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-black hover:bg-zinc-800 text-amber-400 font-bold text-xs rounded-xl transition-colors border border-amber-400/40 shadow-xs"
            title="Скачать Chrome-расширение и код"
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>Chrome-расширение</span>
          </button>

          <button
            onClick={() => setIsImportModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-amber-400 hover:bg-amber-300 text-black font-black text-xs rounded-xl transition-colors shadow-xs"
            title="Импортировать товар по ссылке 1688 или через JSON"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Импорт товара</span>
          </button>

          <button
            onClick={loadAdminData}
            className="p-2 text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors shadow-xs"
            title="Обновить данные"
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          <button
            onClick={handleLogout}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-red-50 hover:bg-red-100 text-red-700 font-semibold text-xs rounded-xl transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Выйти</span>
          </button>
        </div>
      </div>

      {/* ЖЕСТКОЕ ПРЕДУПРЕЖДЕНИЕ О ВОЗВРАТЕ СРЕДСТВ */}
      <div className="p-4 sm:p-5 bg-red-100 border-2 border-red-500 rounded-2xl text-red-950 flex items-start sm:items-center gap-4 shadow-sm">
        <div className="p-2.5 bg-red-200 text-red-700 rounded-xl shrink-0">
          <AlertTriangle className="w-6 h-6" />
        </div>
        <div className="space-y-0.5">
          <div className="font-extrabold text-sm sm:text-base uppercase tracking-wide text-red-900 font-heading">
            ВНИМАНИЕ! СОГЛАСНО ПРАВИЛАМ M.SAVDO:
          </div>
          <div className="text-xs sm:text-sm font-bold text-red-900 leading-snug">
            В случае возврата средств, перевод делать СТРОГО на тот же счет/карту, с которой пришла оплата!
          </div>
        </div>
      </div>

      {/* Вкладки админки */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto text-xs font-bold">
        <button
          onClick={() => setActiveTab('products')}
          className={`px-4 py-2.5 rounded-xl transition-colors flex items-center gap-2 ${
            activeTab === 'products'
              ? 'bg-slate-900 text-white'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Layers className="w-4 h-4 text-emerald-400" />
          <span>Каталог товаров и матрица SKU ({adminProducts.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('gemini_ai')}
          className={`px-4 py-2.5 rounded-xl transition-colors flex items-center gap-2 ${
            activeTab === 'gemini_ai'
              ? 'bg-slate-900 text-white'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Sparkles className="w-4 h-4 text-purple-400" />
          <span>Тестирование ИИ Gemini</span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`px-4 py-2.5 rounded-xl transition-colors flex items-center gap-2 ${
            activeTab === 'settings'
              ? 'bg-slate-900 text-white'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Settings className="w-4 h-4 text-blue-400" />
          <span>Курс, вес и логистика</span>
        </button>
      </div>

      {/* ========================================== */}
      {/* ВКЛАДКА 1: ТОВАРЫ И МАТРИЦА ВАРИАНТОВ */}
      {/* ========================================== */}
      {activeTab === 'products' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm">
            <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Все товары платформы с конфиденциальными полями
                </h3>
                <p className="text-[11px] text-slate-400">
                  Оригинальные ссылки на китайские фабрики и закупочные цены в юанях доступны только вам.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleOpenCreateModal}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs transition-colors shrink-0 shadow-xs"
                  title="Создать товар вручную с нуля"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Создать товар вручную</span>
                </button>

                <button
                  onClick={() => setIsImportModalOpen(true)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-amber-400 hover:bg-amber-300 text-black rounded-xl font-black text-xs transition-colors shrink-0 shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Импорт (1688 / JSON)</span>
                </button>
              </div>
            </div>

            <div className="divide-y divide-slate-100">
              {adminProducts.map((p) => {
                const variants = p.variants || [];
                return (
                  <div key={p.id} className="p-5 hover:bg-slate-50/60 transition-colors space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="flex items-start gap-4">
                        <img
                          src={p.main_image || 'https://placehold.co/100x100?text=M.Savdo'}
                          alt=""
                          referrerPolicy="no-referrer"
                          className="w-14 h-16 rounded-xl object-cover border border-slate-200 shrink-0"
                        />
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded">
                              {p.base_sku}
                            </span>
                            <span className="text-[11px] text-slate-500 font-medium">
                              {p.category_name || 'Общая категория'}
                            </span>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                              p.status === 'active' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                            }`}>
                              {p.status}
                            </span>
                            {p.delivery_type === 'stock' ? (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-600 text-white flex items-center gap-1 shadow-xs">
                                <Truck className="w-2.5 h-2.5" />
                                <span>🚚 В наличии (Душанбе)</span>
                              </span>
                            ) : (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-900 flex items-center gap-1 border border-amber-300">
                                <Clock className="w-2.5 h-2.5 text-amber-700" />
                                <span>⏳ Под заказ (15-30 дн.)</span>
                              </span>
                            )}
                            {p.video_url && (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-800 flex items-center gap-1">
                                <Video className="w-2.5 h-2.5" />
                                <span>Видео</span>
                              </span>
                            )}
                          </div>

                          <h4 className="text-sm font-bold text-slate-900 mt-1">
                            {p.title}
                          </h4>

                          {/* Ссылка на первоисточник (СТРОГО СКРЫТА ОТ КЛИЕНТОВ) */}
                          {p.original_link && (
                            <div className="mt-1 flex items-center gap-1.5 text-xs">
                              <span className="text-slate-400 text-[11px]">Поставщик в Китае:</span>
                              <a
                                href={p.original_link}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-1 text-emerald-700 hover:text-emerald-900 font-semibold underline text-[11px]"
                              >
                                <span>Открыть фабрику</span>
                                <ExternalLink className="w-3 h-3" />
                              </a>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-center">
                        <button
                          onClick={() => handleOpenEditModal(p)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold transition-colors shadow-xs"
                        >
                          <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                          <span>Редактировать товар</span>
                        </button>
                        <button
                          onClick={() => handleDeleteProduct(p.id)}
                          className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg transition-colors"
                          title="Удалить товар"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Сетка вариантов товара */}
                    <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 text-xs">
                      <div className="text-[11px] font-bold text-slate-600 mb-2 flex items-center justify-between">
                        <span>Матрица вариантов ({variants.length} модификаций):</span>
                        <span className="text-slate-400">Цены закупки CNY → Продажа TJS (с весом)</span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                        {variants.map((v: any) => (
                          <div key={v.id} className="bg-white p-2.5 rounded-lg border border-slate-200 text-[11px] space-y-1">
                            <div className="flex justify-between font-bold text-slate-900">
                              <span>{v.color || 'Базовый'} · {v.size}</span>
                              <span className="text-emerald-800 font-mono">{v.price_tjs} TJS</span>
                            </div>
                            <div className="flex justify-between text-slate-500 font-mono text-[10px]">
                              <span>Закуп: ¥{v.price_cny}</span>
                              <span>Вес: {v.weight_kg} кг</span>
                            </div>
                            <div className="flex justify-between text-slate-400 text-[10px]">
                              <span className="font-mono">{v.variant_sku}</span>
                              <span className="text-slate-600 font-medium">Склад: {v.stock} шт.</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ========================================== */}
      {/* ВКЛАДКА 2: ТЕСТИРОВАНИЕ ИИ GEMINI */}
      {/* ========================================== */}
      {activeTab === 'gemini_ai' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-600" />
              <span>Тестирование ИИ-перевода и категоризации Gemini</span>
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Проверьте, как серверный Gemini 3.8 Flash очищает китайские названия от фабричного спама и превращает их в продающие заголовки.
            </p>
          </div>

          <div className="space-y-4 max-w-2xl text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Сырое китайское название товара (из 1688 или Pinduoduo):
              </label>
              <textarea
                rows={3}
                value={geminiTestInput}
                onChange={(e) => setGeminiTestInput(e.target.value)}
                className="w-full p-3 border border-slate-300 rounded-xl text-sm font-sans"
              />
            </div>

            <button
              onClick={handleTestGemini}
              disabled={isGeminiTesting}
              className="px-6 py-3 bg-slate-900 hover:bg-purple-700 text-white font-bold rounded-xl text-xs transition-colors shadow-sm flex items-center gap-2 disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isGeminiTesting ? 'Обработка ИИ...' : 'Обработать через Gemini API'}</span>
            </button>

            {geminiResult && (
              <div className="mt-4 p-5 bg-purple-50/70 border border-purple-200 rounded-2xl space-y-3">
                <div className="font-bold text-purple-950 text-sm">Результат обработки ИИ:</div>
                <div className="space-y-1.5 text-xs text-purple-900">
                  <div><strong>Чистое название:</strong> {geminiResult.title}</div>
                  <div><strong>Подобранная категория:</strong> <span className="bg-purple-200 px-2 py-0.5 rounded font-semibold">{geminiResult.category_name}</span></div>
                  <div><strong>Продающее описание:</strong> {geminiResult.description}</div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================== */}
      {/* ВКЛАДКА 3: НАСТРОЙКИ КУРСА И ВЕСОВОЙ ЛОГИСТИКИ */}
      {/* ========================================== */}
      {activeTab === 'settings' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm max-w-2xl">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Scale className="w-5 h-5 text-emerald-600" />
              <span>Параметры ценообразования и весовой логистики</span>
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              При изменении параметров система автоматически пересчитывает цены всех вариантов для клиентов.
            </p>
          </div>

          <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Курс конвертации (1 CNY в TJS)
              </label>
              <input
                type="number"
                step="0.01"
                required
                value={settings.cny_tjs_rate}
                onChange={(e) => setSettings({ ...settings, cny_tjs_rate: e.target.value })}
                className="w-full p-3 border border-slate-300 rounded-xl text-sm font-mono font-bold"
              />
              <span className="text-[10px] text-slate-400">
                Закупочная цена в юанях умножается на этот курс и коэффициент наценки.
              </span>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Тариф доставки за 1 килограмм (TJS)
              </label>
              <input
                type="number"
                step="1"
                required
                value={settings.delivery_per_kg_tjs}
                onChange={(e) => setSettings({ ...settings, delivery_per_kg_tjs: e.target.value })}
                className="w-full p-3 border border-slate-300 rounded-xl text-sm font-mono font-bold"
              />
              <span className="text-[10px] text-slate-400">
                По регламенту: 30 сомони за 1 кг. Добавляется к цене каждого варианта исходя из его веса.
              </span>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Номер телефона WhatsApp для заказов
              </label>
              <input
                type="text"
                required
                value={settings.whatsapp_phone}
                onChange={(e) => setSettings({ ...settings, whatsapp_phone: e.target.value })}
                className="w-full p-3 border border-slate-300 rounded-xl text-sm font-mono font-bold"
              />
              <span className="text-[10px] text-slate-400">
                Международный формат Таджикистана без плюса (например: 992444431).
              </span>
            </div>

            <div className="pt-3">
              <button
                type="submit"
                className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs transition-colors shadow-sm flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                <span>{settingsSaved ? '✓ Сохранено и пересчитано!' : 'Сохранить и пересчитать весь каталог'}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* МОДАЛЬНОЕ ОКНО ПОЛНОЦЕННОГО РЕДАКТИРОВАНИЯ И РУЧНОГО СОЗДАНИЯ ТОВАРА */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl max-w-3xl w-full p-5 sm:p-7 shadow-2xl border border-slate-200 max-h-[92vh] overflow-y-auto space-y-5 text-xs">
            <div className="flex justify-between items-start border-b border-slate-200 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base sm:text-lg font-bold text-slate-900 font-heading">
                    {editingProduct.id === 0 ? 'Создание нового товара вручную' : `Редактирование: ${editingProduct.base_sku}`}
                  </h3>
                  <span className="font-mono text-[10px] font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
                    {editingProduct.base_sku}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Полная настройка карточки, галереи, видео, типа доставки и матрицы вариантов SKU
                </p>
              </div>
              <button 
                onClick={() => setEditingProduct(null)} 
                className="p-1.5 text-slate-400 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
              >
                ✕
              </button>
            </div>

            {productSaveError && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs font-semibold text-red-700 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-red-600" />
                <span>{productSaveError}</span>
              </div>
            )}

            <form onSubmit={handleSaveProduct} className="space-y-4">
              {/* НАЗВАНИЕ */}
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  Название товара (для клиентской витрины) <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={editingProduct.title}
                  onChange={(e) => setEditingProduct({ ...editingProduct, title: e.target.value })}
                  placeholder="Например: Мужские кожаные дышащие туфли"
                  className="w-full p-2.5 border border-slate-300 rounded-xl text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>

              {/* ОПИСАНИЕ */}
              <div>
                <label className="block font-bold text-slate-800 mb-1">Описание модели</label>
                <textarea
                  rows={3}
                  value={editingProduct.description}
                  onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                  placeholder="Преимущества, материалы, посадка и сезонность..."
                  className="w-full p-2.5 border border-slate-300 rounded-xl text-xs text-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>

              {/* ДВА ТИПА ТОВАРОВ («В НАЛИЧИИ» И «ПОД ЗАКАЗ») */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-2">
                <label className="block font-bold text-slate-800 text-xs">
                  Тип наличия и срок доставки товара:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <label className={`p-3 rounded-xl border-2 cursor-pointer flex items-start gap-2.5 transition-all ${
                    editingProduct.delivery_type === 'stock'
                      ? 'bg-emerald-50/80 border-emerald-500 text-emerald-950 font-bold shadow-xs'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100/60'
                  }`}>
                    <input
                      type="radio"
                      name="delivery_type"
                      value="stock"
                      checked={editingProduct.delivery_type === 'stock'}
                      onChange={() => setEditingProduct({ ...editingProduct, delivery_type: 'stock' })}
                      className="mt-1 text-emerald-600 focus:ring-emerald-500"
                    />
                    <div>
                      <div className="flex items-center gap-1.5 text-emerald-900 font-bold">
                        <Truck className="w-4 h-4 text-emerald-600" />
                        <span>🚚 В наличии (Склад в Душанбе)</span>
                      </div>
                      <div className="text-[10px] text-slate-500 font-normal mt-0.5">
                        Товар уже в наличии. Доставка клиенту за 1 день курьером.
                      </div>
                    </div>
                  </label>

                  <label className={`p-3 rounded-xl border-2 cursor-pointer flex items-start gap-2.5 transition-all ${
                    editingProduct.delivery_type === 'order'
                      ? 'bg-amber-50/80 border-amber-500 text-amber-950 font-bold shadow-xs'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100/60'
                  }`}>
                    <input
                      type="radio"
                      name="delivery_type"
                      value="order"
                      checked={editingProduct.delivery_type === 'order'}
                      onChange={() => setEditingProduct({ ...editingProduct, delivery_type: 'order' })}
                      className="mt-1 text-amber-600 focus:ring-amber-500"
                    />
                    <div>
                      <div className="flex items-center gap-1.5 text-amber-900 font-bold">
                        <Clock className="w-4 h-4 text-amber-600" />
                        <span>⏳ Под заказ: 15-30 дней напрямую с фабрики</span>
                      </div>
                      <div className="text-[10px] text-slate-500 font-normal mt-0.5">
                        Прямая доставка с фабрики поставщика в Китае в Душанбе.
                      </div>
                    </div>
                  </label>
                </div>
              </div>

              {/* КАТЕГОРИЯ (ЗАБЛОКИРОВАНА ДЛЯ РУЧНОГО ВВОДА С ИИ-ПЛАШКОЙ) И СТАТУС */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="font-bold text-slate-800 text-xs">Категория товара</label>
                    <span className="text-[10px] font-bold text-purple-700 bg-purple-100 border border-purple-200 px-2 py-0.5 rounded-full flex items-center gap-1">
                      <Sparkles className="w-2.5 h-2.5 text-purple-600" />
                      <span>ИИ-определение Gemini</span>
                    </span>
                  </div>
                  <div className="relative">
                    <input
                      type="text"
                      disabled
                      readOnly
                      value={editingProduct.category_name || 'Определится автоматически через Gemini 3.8 Flash'}
                      className="w-full p-2.5 bg-slate-100 border border-slate-300 rounded-xl text-xs font-bold text-slate-700 cursor-not-allowed pl-8 shadow-inner"
                    />
                    <Lock className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
                  </div>
                  <p className="text-[10px] text-slate-400">
                    Категория заблокирована от ручного ввода. Сервер автоматически определит категорию на основе названия через Gemini 3.8 Flash при сохранении.
                  </p>
                </div>

                <div className="space-y-1">
                  <label className="block font-bold text-slate-800 text-xs">Статус на витрине</label>
                  <select
                    value={editingProduct.status}
                    onChange={(e) => setEditingProduct({ ...editingProduct, status: e.target.value })}
                    className="w-full p-2.5 border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
                  >
                    <option value="active">active (Отображается на витрине)</option>
                    <option value="draft">draft (Скрыт в черновиках)</option>
                  </select>
                </div>
              </div>

              {/* ВИДЕО (YOUTUBE / DIRECT MP4) */}
              <div className="space-y-1">
                <label className="block font-bold text-slate-800 text-xs">
                  Видеообзор товара (YouTube или прямая ссылка mp4)
                </label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    value={editingProduct.video_url || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, video_url: e.target.value })}
                    placeholder="https://www.youtube.com/watch?v=... или https://youtu.be/... или https://...mp4"
                    className="w-full p-2.5 border border-slate-300 rounded-xl text-xs text-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
                <p className="text-[10px] text-slate-400">
                  YouTube ссылки автоматически конвертируются во встроенный интерактивный видеоплеер.
                </p>
              </div>

              {/* ФОТОГАЛЕРЕЯ ТОВАРА */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-800 text-xs">
                    Фотогалерея ({editingProduct.images?.length || 0} фото):
                  </label>
                  <span className="text-[10px] text-slate-400">
                    Нажмите «Сделать главным», чтобы назначить обложку
                  </span>
                </div>

                {/* Добавление фото */}
                <div className="flex gap-2">
                  <input
                    type="url"
                    value={newImageUrl}
                    onChange={(e) => setNewImageUrl(e.target.value)}
                    placeholder="Вставьте ссылку на качественное фото (https://...)"
                    className="flex-1 p-2 bg-white border border-slate-300 rounded-xl text-xs"
                  />
                  <button
                    type="button"
                    onClick={handleAddGalleryImage}
                    className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition-colors shrink-0"
                  >
                    + Добавить фото
                  </button>
                </div>

                {/* Сетка фото */}
                {editingProduct.images && editingProduct.images.length > 0 && (
                  <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2 pt-1">
                    {editingProduct.images.map((img: string, idx: number) => {
                      const isMain = editingProduct.main_image === img || (idx === 0 && !editingProduct.main_image);
                      return (
                        <div key={idx} className="relative group rounded-xl overflow-hidden border border-slate-300 aspect-square bg-slate-200">
                          <img src={img} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          {isMain && (
                            <span className="absolute top-1 left-1 bg-amber-400 text-black text-[9px] font-black px-1.5 py-0.5 rounded shadow-xs">
                              Главное
                            </span>
                          )}
                          <div className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-1 p-1">
                            {!isMain && (
                              <button
                                type="button"
                                onClick={() => setEditingProduct({ ...editingProduct, main_image: img })}
                                className="px-1.5 py-0.5 bg-amber-400 text-black text-[9px] font-bold rounded shadow-xs hover:bg-amber-300"
                              >
                                Сделать главным
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => handleRemoveGalleryImage(idx)}
                              className="p-1 bg-red-600 text-white rounded hover:bg-red-700"
                              title="Удалить из галереи"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* МАТРИЦА SKU ВАРИАНТОВ */}
              <div className="space-y-2 pt-2 border-t border-slate-200">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="font-bold text-slate-800 text-xs">Матрица вариантов SKU:</label>
                    <p className="text-[10px] text-slate-400">Цвета, размеры, цены в TJS и привязанные фото</p>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddVariantRow}
                    className="inline-flex items-center gap-1 px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-black font-black text-xs rounded-xl transition-colors shadow-xs"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+ Добавить вариант</span>
                  </button>
                </div>

                <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                  {editingProduct.variants?.map((v: any, vIdx: number) => (
                    <div key={vIdx} className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl grid grid-cols-1 sm:grid-cols-6 gap-2 items-center text-xs">
                      <div>
                        <span className="block text-[10px] font-bold text-slate-500 mb-0.5">Цвет:</span>
                        <input
                          type="text"
                          required
                          value={v.color || ''}
                          onChange={(e) => handleUpdateVariantField(vIdx, 'color', e.target.value)}
                          placeholder="Черный"
                          className="w-full p-1.5 bg-white border border-slate-300 rounded-lg text-xs font-semibold"
                        />
                      </div>
                      <div>
                        <span className="block text-[10px] font-bold text-slate-500 mb-0.5">Размер:</span>
                        <input
                          type="text"
                          required
                          value={v.size || ''}
                          onChange={(e) => handleUpdateVariantField(vIdx, 'size', e.target.value)}
                          placeholder="42 / L"
                          className="w-full p-1.5 bg-white border border-slate-300 rounded-lg text-xs"
                        />
                      </div>
                      <div>
                        <span className="block text-[10px] font-bold text-slate-500 mb-0.5">Цена TJS (продажа):</span>
                        <input
                          type="number"
                          required
                          min="1"
                          value={v.price_tjs || 0}
                          onChange={(e) => handleUpdateVariantField(vIdx, 'price_tjs', Number(e.target.value))}
                          className="w-full p-1.5 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900"
                        />
                      </div>
                      <div>
                        <span className="block text-[10px] font-bold text-slate-500 mb-0.5">Склад (шт.):</span>
                        <input
                          type="number"
                          min="0"
                          value={v.stock !== undefined ? v.stock : 10}
                          onChange={(e) => handleUpdateVariantField(vIdx, 'stock', Number(e.target.value))}
                          className="w-full p-1.5 bg-white border border-slate-300 rounded-lg text-xs"
                        />
                      </div>
                      <div>
                        <span className="block text-[10px] font-bold text-slate-500 mb-0.5">Фото варианта:</span>
                        <div className="flex items-center gap-1">
                          {v.image_url && (
                            <img src={v.image_url} alt="" className="w-6 h-6 rounded object-cover border border-slate-300 shrink-0" referrerPolicy="no-referrer" />
                          )}
                          <input
                            type="url"
                            value={v.image_url || ''}
                            onChange={(e) => handleUpdateVariantField(vIdx, 'image_url', e.target.value)}
                            placeholder="URL фото"
                            className="w-full p-1.5 bg-white border border-slate-300 rounded-lg text-[10px]"
                          />
                        </div>
                      </div>
                      <div className="flex justify-end sm:pt-4">
                        <button
                          type="button"
                          disabled={editingProduct.variants.length <= 1}
                          onClick={() => handleRemoveVariantRow(vIdx)}
                          className="p-1.5 text-slate-400 hover:text-red-600 disabled:opacity-30 rounded-lg"
                          title="Удалить вариант"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* КНОПКИ ДЕЙСТВИЙ */}
              <div className="pt-4 flex justify-between items-center border-t border-slate-200">
                <button
                  type="button"
                  disabled={isSavingProduct}
                  onClick={() => setEditingProduct(null)}
                  className="px-4 py-2 border border-slate-300 rounded-xl text-slate-600 font-medium hover:bg-slate-50 transition-colors"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  disabled={isSavingProduct}
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition-colors shadow-sm disabled:opacity-50 flex items-center gap-2"
                >
                  {isSavingProduct ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>ИИ определяет категорию и сохраняет...</span>
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4" />
                      <span>{editingProduct.id === 0 ? 'Создать товар' : 'Сохранить изменения'}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Модальное окно импорта товара */}
      <ImportProductModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onSuccess={() => {
          loadAdminData();
          onRefreshCatalog();
        }}
      />

      {/* Модальное окно файлов и Chrome-расширения */}
      <ExportCodeModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
      />

    </div>
  );
};
