// content.js — M.Savdo Universal AI Merchant Co-Pilot v5.5 (Enterprise Multi-SKU & Visual Map)
// 1. Очистка галереи: фильтрация иконок, баннеров, аватарок и фото < 300px
// 2. Карта картинок вариантов (Visual SKU Map): связывание китайских цветов с их точными фотографиями
// 3. Отправка на бэкенд /api/add-product с сырым текстом, ценой, чистыми фото и visual_sku_map для ИИ Gemini
// 4. ИИ-Бухгалтер: дифференцированная наценка (100% / 60% / 30%) + 30 с/кг логистики
// 5. ИИ-Таргетолог: готовые рекламные материалы для Instagram @MSavdo.tj

(function () {
  "use strict";

  console.log("[M.Savdo Co-Pilot v5.5] Активация на странице:", window.location.href);

  // ==========================================
  // СЛОВАРИ ЦВЕТОВ И ТЕРМИНОВ
  // ==========================================
  const COLOR_MAP = {
    '黑色': 'Черный', '纯黑': 'Глубокий черный', '亮黑': 'Глянцевый черный',
    '蓝色': 'Синий (Cyan)', '深蓝': 'Темно-синий', '天蓝': 'Небесно-голубой',
    '红色': 'Красный (Magenta)', '酒红': 'Бордовый', '粉色': 'Розовый',
    '黄色': 'Желтый (Yellow)', '绿色': 'Зеленый', '军绿': 'Оливковый хаки',
    '白色': 'Белый', '米白': 'Молочный белый', '灰色': 'Серый',
    '深灰': 'Темно-серый', '浅灰': 'Светло-серый', '银色': 'Серебристый',
    '金色': 'Золотистый', '咖色': 'Кофейный', '咖啡色': 'Кофейный',
    '卡其色': 'Хаки', '卡其': 'Хаки', '棕色': 'Коричневый', '橙色': 'Оранжевый',
    '紫色': 'Фиолетовый', '青色': 'Бирюзовый', '透明': 'Прозрачный',
    '米黄': 'Бежевый', '藏青': 'Темно-синий', '墨绿': 'Изумрудный'
  };

  const SPEC_TERMS = [
    { reg: /爱普生/gi, rep: 'Epson' }, { reg: /佳能/gi, rep: 'Canon' }, { reg: /惠普/gi, rep: 'HP' },
    { reg: /兼容/gi, rep: 'Совместимый' }, { reg: /墨水瓶/gi, rep: 'флакон чернил' },
    { reg: /墨水/gi, rep: 'чернила' }, { reg: /墨盒/gi, rep: 'картридж' },
    { reg: /染料/gi, rep: 'Dye' }, { reg: /颜料/gi, rep: 'Pigment' },
    { reg: /厚底/gi, rep: 'на толстой подошве' }, { reg: /劳保/gi, rep: 'защитные' },
    { reg: /皮鞋/gi, rep: 'туфли' }, { reg: /透气/gi, rep: 'дышащие' },
    { reg: /防滑/gi, rep: 'нескользящие' }, { reg: /耐磨/gi, rep: 'износостойкие' },
    { reg: /卫衣/gi, rep: 'худи' }, { reg: /外套/gi, rep: 'куртка' },
    { reg: /手机壳/gi, rep: 'чехол' }, { reg: /耳机/gi, rep: 'наушники' },
    { reg: /手表/gi, rep: 'смарт-часы' }, { reg: /(\d+)\s*(ml|毫升)/gi, rep: '$1 мл' },
    { reg: /(\d+)\s*(g|克)/gi, rep: '$1 г' }
  ];

  const SHOP_STOP_WORDS = [
    '中山市', '温县', '干恒', '墨飞印', '制鞋厂', '鞋厂', '制衣厂', '五金厂', '电子厂', '加工厂',
    '有限公司', '责任公司', '商行', '经营部', '商贸', '实业', '科技公司', '旗舰店', '专营店',
    '厂家直销', '源头好货', '源头工厂', '一件代发', '支持混批', '批发特价', '热销爆款',
    '跨境专供', '2026新款', '2025新款', '爆款推荐', '限时特价', '包邮', '专柜正品',
    '入驻2年', '入驻4年', '入驻1年', '主营', '品质承诺', '进店看看', '已关注', '客服', '严选',
    '假一赔四', '墨合', '工厂直供'
  ];

  function isShopText(str) {
    if (!str) return true;
    const lower = str.trim().toLowerCase();
    if (lower.length < 3) return true;
    for (const stop of SHOP_STOP_WORDS) {
      if (lower.includes(stop.toLowerCase())) return true;
    }
    return false;
  }

  function isPageTranslatedToRussian() {
    const text = (document.title + ' ' + (document.body?.innerText || "").slice(0, 800)).toLowerCase();
    const cyrillicMatches = text.match(/[а-яё]/gi);
    return cyrillicMatches && cyrillicMatches.length > 20;
  }

  // ==========================================
  // 1. ИЗВЛЕЧЕНИЕ ЗАГОЛОВКА
  // ==========================================
  function extractProductTitle() {
    try {
      const docTitle = document.title || "";
      let cleanDoc = docTitle
        .replace(/[-|_].*(阿里巴巴|淘宝网|拼多多|1688|alibaba|taobao|tmall).*$/i, "")
        .replace(/[-|_].*$/, "")
        .trim();
      
      if (cleanDoc.length >= 8 && !isShopText(cleanDoc)) {
        return cleanDoc.replace(/\s+/g, ' ').trim();
      }

      const ogTitle = document.querySelector("meta[property='og:title']")?.content;
      if (ogTitle && ogTitle.length >= 6 && !isShopText(ogTitle)) {
        return ogTitle.replace(/[-|_].*$/, "").trim();
      }

      const selectors = [
        ".title-content", ".od-pc-offer-title", "[class*='ItemHeader--mainTitle']",
        "[class*='ItemTitle--title']", "[class*='title--title']", "h1.d-title",
        "h1[class*='title']", "[class*='offer-title']", "[class*='goods-name']"
      ];

      for (const sel of selectors) {
        const elements = document.querySelectorAll(sel);
        for (const el of elements) {
          if (el.closest('.shop-info, .shop-header, .company-name, [class*="shop-"], [class*="seller-"], header, nav')) continue;
          const text = (el.innerText || el.textContent || "").trim();
          if (text.length >= 6 && !isShopText(text)) {
            return text.replace(/\s+/g, ' ').trim();
          }
        }
      }

      return cleanDoc || "Качественный фабричный товар";
    } catch (e) {
      return "Качественный фабричный товар";
    }
  }

  // ==========================================
  // 2. ИЗВЛЕЧЕНИЕ БАЗОВОЙ ЦЕНЫ В ЮАНЯХ (CNY)
  // ==========================================
  function extractBasePriceCny() {
    try {
      const validPrices = [];
      const sizeRows = document.querySelectorAll("[class*='size-item'], [class*='sku-list'] tr, [class*='table'] tr, [class*='sku-item'], [class*='item-row']");
      for (const row of sizeRows) {
        const match = (row.innerText || "").match(/[¥￥]\s*([0-9]+(?:\.[0-9]+)?)/);
        if (match) {
          const val = parseFloat(match[1]);
          if (val >= 0.5 && val <= 100000) validPrices.push(val);
        }
      }

      const priceSelectors = [
        "[class*='Price--priceText']", "[class*='price-num']", ".price-text",
        ".od-pc-offer-price", "[class*='priceNow']", "[class*='strong-num']",
        "[class*='price-text']", ".price"
      ];
      for (const sel of priceSelectors) {
        const elements = document.querySelectorAll(sel);
        for (const el of elements) {
          const text = (el.innerText || "").trim();
          const m = text.match(/[¥￥]\s*([0-9]+(?:\.[0-9]+)?)/) || text.match(/([0-9]+(?:\.[0-9]+)?)/);
          if (m) {
            const val = parseFloat(m[1]);
            if (val >= 0.5 && val <= 100000) validPrices.push(val);
          }
        }
      }

      if (validPrices.length > 0) {
        validPrices.sort((a, b) => a - b);
        return Number(validPrices[0].toFixed(2));
      }
      return 50.0;
    } catch (e) {
      return 50.0;
    }
  }

  // ==========================================
  // 3. СТРОГАЯ ОЧИСТКА ГАЛЕРЕИ (БЕЗ ИКОНОК И <300px)
  // ==========================================
  function extractCleanImages() {
    const images = [];
    const seen = new Set();
    const badTokens = [
      'icon', 'logo', 'qrcode', 'avatar', 'banner', 'chevron', 'arrow',
      'cert', 'verify', 'watermark', 'loading', 'placeholder', 'express', 'truck'
    ];

    const addImg = (imgEl, rawUrl) => {
      let clean = (rawUrl || imgEl?.src || imgEl?.getAttribute("data-lazy-src") || imgEl?.getAttribute("data-src") || "").trim();
      if (!clean) return;

      if (clean.startsWith("//")) clean = "https:" + clean;
      if (!clean.startsWith("http://") && !clean.startsWith("https://")) return;
      if (clean.includes("data:image") || clean.endsWith(".gif") || clean.length < 25) return;

      const lower = clean.toLowerCase();
      for (const token of badTokens) {
        if (lower.includes(token)) return;
      }

      // Проверка размера картинки (если элемент доступен)
      if (imgEl && (imgEl.naturalWidth > 0 && imgEl.naturalWidth < 300 && imgEl.naturalHeight < 300)) {
        return;
      }

      // Получаем полноразмерное изображение, удаляя китайские суффиксы обрезки
      clean = clean
        .replace(/_\d+x\d+.*$/i, "")
        .replace(/\.search\..*$/i, "")
        .replace(/_b\.jpg.*$/i, ".jpg")
        .replace(/\.300x300.*$/i, "");

      if (!seen.has(clean)) {
        images.push(clean);
        seen.add(clean);
      }
    };

    try {
      const og = document.querySelector("meta[property='og:image']")?.content;
      if (og) addImg(null, og);

      // Картинки основной галереи оффера
      const galleryImgs = document.querySelectorAll(
        ".detail-gallery-turn img, .od-pc-offer-gallery img, [class*='gallery'] img, .main-image img, [class*='main-img'] img, [class*='banner'] img"
      );
      for (const img of galleryImgs) {
        addImg(img);
      }

      // Картинки вариантов
      const skuImgs = document.querySelectorAll("[class*='prop-item'] img, [class*='sku-item'] img, [class*='color-item'] img");
      for (const img of skuImgs) {
        addImg(img);
      }
    } catch (e) {
      console.warn("Ошибка галереи фото:", e);
    }

    return images.slice(0, 10);
  }

  // ==========================================
  // 4. КАРТА КАРТИНОК ВАРИАНТОВ (VISUAL SKU MAP)
  // Связывает китайское название цвета с его фото
  // ==========================================
  function extractVisualSkuMap() {
    const visualSkuMap = [];
    const seenColors = new Set();

    const colorSelectors = [
      "[class*='prop-item']",
      "[class*='sku-prop-item']",
      "[class*='color-item']",
      "[class*='sku-item']",
      "[class*='attr-item']",
      "[class*='item-prop']",
      ".od-pc-attribute-sku-item",
      ".sku-filter-item",
      "div[data-spm*='color']"
    ];

    for (const sel of colorSelectors) {
      const items = document.querySelectorAll(sel);
      for (const item of items) {
        const imgEl = item.querySelector("img");
        let imgUrl = imgEl?.src || imgEl?.getAttribute("data-lazy-src") || imgEl?.getAttribute("data-src") || "";
        if (imgUrl) {
          if (imgUrl.startsWith("//")) imgUrl = "https:" + imgUrl;
          imgUrl = imgUrl.replace(/_\d+x\d+.*$/i, "").replace(/\.search\..*$/i, "").replace(/_b\.jpg.*$/i, ".jpg");
        }

        let rawColor = (item.getAttribute("title") || item.getAttribute("aria-label") || item.innerText || "").trim();
        rawColor = rawColor.replace(/[\n\r]+/g, " ").replace(/\s+/g, " ").trim();

        if (rawColor && imgUrl && !seenColors.has(rawColor) && imgUrl.startsWith("http")) {
          seenColors.add(rawColor);
          visualSkuMap.push({
            raw_color: rawColor,
            image_url: imgUrl
          });
        }
      }
      if (visualSkuMap.length > 0) break;
    }

    return visualSkuMap;
  }

  // ==========================================
  // 5. ИЗВЛЕЧЕНИЕ ВИДЕО 1688
  // ==========================================
  function extractVideoUrl() {
    try {
      const videoEl = document.querySelector("video");
      let src = videoEl?.currentSrc || videoEl?.src || videoEl?.querySelector("source")?.src || "";

      if (!src) {
        const dataEl = document.querySelector("[data-video-url], [data-video], [class*='video'] video");
        src = dataEl?.getAttribute("data-video-url") || dataEl?.getAttribute("data-src") || "";
      }

      if (!src) {
        const html = document.documentElement.innerHTML;
        const mp4Match = html.match(/https?:\\\/\\\/[^"'\s<>]+\.mp4/i) || html.match(/\/\/[^"'\s<>]+\.mp4/i);
        if (mp4Match) {
          src = mp4Match[0].replace(/\\/g, '');
        }
      }

      if (src && src.startsWith("//")) src = "https:" + src;
      return (src && src.startsWith("http")) ? src : "";
    } catch (e) {
      return "";
    }
  }

  // ==========================================
  // 6. СТРОГАЯ ФИНАНСОВАЯ МАТЕМАТИКА (TJS)
  // ==========================================
  function calculateVariantPriceTjs(priceCny, weightKg = 0.5, rate = 1.45) {
    let markup = 1.6;
    if (priceCny <= 20) {
      markup = 2.0; // 100% наценка
    } else if (priceCny <= 100) {
      markup = 1.6; // 60% наценка
    } else {
      markup = 1.3; // 30% наценка
    }
    const productTjs = priceCny * rate * markup;
    const deliveryTjs = weightKg * 30; // 30 сомони за 1 кг
    return Math.round(productTjs + deliveryTjs);
  }

  // ==========================================
  // СБОР ЧИСТОГО ТЕКСТОВОГО СЛОЯ
  // ==========================================
  function extractCleanTextLayer() {
    try {
      const clone = (document.body || document.documentElement).cloneNode(true);
      const junkSelectors = [
        "script", "style", "noscript", "svg", "iframe", "canvas",
        "#msavdo-modal-enterprise", "#msavdo-floating-container", "#msavdo-edge-tab",
        "[aria-hidden='true']", "[hidden]", "[style*='display: none']", "[style*='display:none']"
      ];
      for (const sel of junkSelectors) {
        const nodes = clone.querySelectorAll(sel);
        for (const n of nodes) n.remove();
      }
      const text = clone.innerText || clone.textContent || "";
      return text
        .replace(/[ \t]+/g, " ")
        .replace(/\n\s*\n+/g, "\n")
        .trim()
        .slice(0, 35000);
    } catch (e) {
      return (document.body?.innerText || "").slice(0, 35000);
    }
  }

  // Сбор данных товара
  function gatherProductState() {
    const isTranslated = isPageTranslatedToRussian();
    const realTitle = extractProductTitle();
    const basePriceCny = extractBasePriceCny();
    const images = extractCleanImages();
    const visualSkuMap = extractVisualSkuMap();
    const videoUrl = extractVideoUrl();
    const rawHtmlText = extractCleanTextLayer();

    return {
      isTranslated,
      realTitle,
      basePriceCny,
      images,
      visualSkuMap,
      videoUrl,
      rawHtmlText
    };
  }

  // ==========================================
  // 7. МОДАЛЬНОЕ ОКНО CO-PILOT
  // ==========================================
  function openImporterModal(state) {
    const old = document.getElementById("msavdo-modal-enterprise");
    if (old) old.remove();

    let weightKg = 0.5;
    let baseCny = state.basePriceCny;
    let currentImages = [...state.images];
    let visualSkuMap = state.visualSkuMap || [];

    const overlay = document.createElement("div");
    overlay.id = "msavdo-modal-enterprise";
    Object.assign(overlay.style, {
      position: "fixed",
      inset: "0",
      backgroundColor: "rgba(0, 0, 0, 0.85)",
      backdropFilter: "blur(8px)",
      zIndex: "2147483647",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: "16px",
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    });

    const box = document.createElement("div");
    Object.assign(box.style, {
      backgroundColor: "#ffffff",
      borderRadius: "24px",
      maxWidth: "680px",
      width: "100%",
      maxHeight: "92vh",
      overflowY: "auto",
      boxShadow: "0 25px 60px -15px rgba(0, 0, 0, 0.7)",
      border: "3px solid #FACC15",
      padding: "24px",
      color: "#0f172a",
      boxSizing: "border-box"
    });

    function renderModal() {
      const priceTjs = calculateVariantPriceTjs(baseCny, weightKg, 1.45);
      const deliveryTjs = Math.round(weightKg * 30);
      const costTjs = Math.round(baseCny * 1.45 + deliveryTjs);
      const profitTjs = priceTjs - costTjs;

      box.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #e2e8f0; padding-bottom:14px; margin-bottom:16px;">
          <div style="display:flex; align-items:center; gap:12px;">
            <div style="width:42px; height:42px; background:#000000; border:2px solid #FACC15; border-radius:12px; display:flex; align-items:center; justify-content:center;">
              <span style="color:#FACC15; font-size:22px; font-weight:900;">M</span>
            </div>
            <div>
              <div style="display:flex; align-items:center; gap:8px;">
                <span style="font-size:19px; font-weight:900; color:#000000;">M.SAVDO</span>
                <span style="background:#FACC15; color:#000000; font-size:10px; font-weight:800; padding:2px 8px; border-radius:6px;">ENTERPRISE CO-PILOT</span>
              </div>
              <div style="font-size:11px; color:#64748b; font-weight:600;">
                Мульти-вариативный ИИ-импорт · Gemini 3.8 Flash · <strong>@MSavdo.tj</strong>
              </div>
            </div>
          </div>
          <button id="msavdo-close-btn" style="background:#f1f5f9; border:none; width:34px; height:34px; border-radius:9999px; font-size:16px; font-weight:700; cursor:pointer;">✕</button>
        </div>

        <div style="margin-bottom:14px;">
          <label style="display:block; font-weight:700; font-size:11px; margin-bottom:4px; color:#475569;">Заголовок со страницы (будет переведен Gemini):</label>
          <input id="msavdo-inp-title" type="text" value="${escapeHtml(state.realTitle)}" style="width:100%; box-sizing:border-box; padding:10px 12px; border:2px solid #cbd5e1; border-radius:12px; font-size:13px; font-weight:700;">
        </div>

        <!-- ФИНАНСОВЫЙ БЛОК -->
        <div style="background:#000000; color:#ffffff; border-radius:16px; padding:16px; border:2px solid #FACC15; margin-bottom:14px;">
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">
            <div>
              <div style="font-size:11px; color:#94a3b8;">Розничная цена (TJS):</div>
              <div style="font-size:26px; font-weight:900; color:#FACC15; font-family:monospace;">
                ${priceTjs} сомони
              </div>
              <div style="font-size:10px; color:#94a3b8; margin-top:2px;">
                Формула: CNY × 1.45 × наценка + (${deliveryTjs} с. доставка)
              </div>
            </div>
            <div style="border-left:1px solid #334155; padding-left:14px;">
              <div style="font-size:11px; color:#a7f3d0;">ЧИСТАЯ ПРИБЫЛЬ:</div>
              <div style="font-size:24px; font-weight:900; color:#10b981; font-family:monospace;">
                +${profitTjs} с./шт.
              </div>
              <div style="font-size:10px; color:#94a3b8; margin-top:2px;">
                🚚 Доставка: 15–30 дней напрямую с фабрики
              </div>
            </div>
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:14px;">
          <div>
            <label style="display:block; font-weight:700; font-size:11px; margin-bottom:4px; color:#475569;">Базовая закупка (CNY ¥):</label>
            <input id="msavdo-inp-cny" type="number" step="0.1" value="${baseCny}" style="width:100%; box-sizing:border-box; padding:8px 10px; border:1px solid #cbd5e1; border-radius:10px; font-size:14px; font-weight:800; font-family:monospace; color:#dc2626;">
          </div>
          <div>
            <label style="display:block; font-weight:700; font-size:11px; margin-bottom:4px; color:#475569;">Вес единицы (кг):</label>
            <input id="msavdo-inp-weight" type="number" step="0.05" value="${weightKg}" style="width:100%; box-sizing:border-box; padding:8px 10px; border:1px solid #cbd5e1; border-radius:10px; font-size:14px; font-weight:800; font-family:monospace;">
          </div>
        </div>

        <!-- КАРТА ЦВЕТОВ (VISUAL SKU MAP) -->
        <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:14px; padding:12px; margin-bottom:14px;">
          <div style="font-weight:800; font-size:12px; color:#0f172a; margin-bottom:6px;">
            🎨 Карта картинок вариантов (найдено: ${visualSkuMap.length} шт.):
          </div>
          ${visualSkuMap.length > 0 ? `
            <div style="display:flex; gap:8px; overflow-x:auto; padding-bottom:6px;">
              ${visualSkuMap.map(m => `
                <div style="display:flex; flex-direction:column; align-items:center; background:#ffffff; border:1px solid #e2e8f0; border-radius:8px; padding:4px 6px; shrink-0;">
                  <img src="${m.image_url}" style="width:36px; height:36px; object-fit:cover; border-radius:6px; margin-bottom:2px;">
                  <span style="font-size:9px; font-weight:700; color:#334155; max-width:50px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${escapeHtml(m.raw_color)}</span>
                </div>
              `).join('')}
            </div>
          ` : `
            <div style="font-size:11px; color:#64748b;">Цветовые миниатюры не обнаружены или товар одноцветный. ИИ использует основную галерею.</div>
          `}
        </div>

        <!-- ГАЛЕРЕЯ ЧИСТЫХ ФОТО -->
        <div style="margin-bottom:14px;">
          <div style="font-weight:700; font-size:11px; color:#475569; margin-bottom:4px;">
            Чистая галерея (${currentImages.length} фото без иконок):
          </div>
          <div style="display:flex; gap:6px; overflow-x:auto; padding-bottom:4px;">
            ${currentImages.map((img, idx) => `
              <div style="position:relative; width:48px; height:48px; flex-shrink:0;">
                <img src="${img}" style="width:100%; height:100%; object-fit:cover; border-radius:8px; border:1px solid #e2e8f0;">
                <button type="button" class="msavdo-del-img" data-idx="${idx}" style="position:absolute; top:-3px; right:-3px; width:16px; height:16px; background:#dc2626; color:#ffffff; border:none; border-radius:9999px; font-size:9px; cursor:pointer;">✕</button>
              </div>
            `).join('')}
          </div>
        </div>

        <div id="msavdo-status-msg" style="display:none; padding:10px; border-radius:12px; font-size:11px; font-weight:600; line-height:1.4; margin-bottom:14px;"></div>

        <!-- КНОПКИ ДЕЙСТВИЯ -->
        <div style="display:flex; justify-content:space-between; align-items:center; gap:8px;">
          <button id="msavdo-btn-copy-payload" type="button" style="padding:10px 14px; background:#ffffff; border:1px solid #cbd5e1; border-radius:12px; font-weight:700; font-size:12px; cursor:pointer;">
            📋 Скопировать JSON
          </button>
          <div style="display:flex; gap:8px;">
            <button id="msavdo-btn-cancel" style="padding:10px 16px; background:#f1f5f9; border:none; border-radius:12px; font-weight:700; cursor:pointer; font-size:12px;">Отмена</button>
            <button id="msavdo-btn-submit" style="padding:10px 22px; background:#000000; border:2px solid #FACC15; border-radius:12px; font-weight:800; color:#FACC15; cursor:pointer; font-size:13px; box-shadow:0 4px 15px rgba(0,0,0,0.25);">
              🚀 Отправить в Gemini на импорт
            </button>
          </div>
        </div>
      `;

      // Слушатели событий
      document.getElementById("msavdo-close-btn").onclick = () => overlay.remove();
      document.getElementById("msavdo-btn-cancel").onclick = () => overlay.remove();

      document.getElementById("msavdo-inp-cny").onchange = (e) => {
        baseCny = parseFloat(e.target.value) || 50;
        renderModal();
      };
      document.getElementById("msavdo-inp-weight").onchange = (e) => {
        weightKg = parseFloat(e.target.value) || 0.5;
        renderModal();
      };

      document.querySelectorAll(".msavdo-del-img").forEach(btn => {
        btn.onclick = (e) => {
          e.stopPropagation();
          const idx = parseInt(btn.getAttribute("data-idx"), 10);
          if (!isNaN(idx)) {
            currentImages.splice(idx, 1);
            renderModal();
          }
        };
      });

      // Копирование payload
      document.getElementById("msavdo-btn-copy-payload").onclick = () => {
        const payload = {
          raw_html_text: state.rawHtmlText,
          price_cny: baseCny,
          weight_kg: weightKg,
          original_link: window.location.href,
          images: currentImages.join(","),
          visual_sku_map: visualSkuMap,
          video_url: state.videoUrl
        };
        navigator.clipboard.writeText(JSON.stringify(payload, null, 2)).then(() => {
          alert("✓ JSON товара с картой картинок вариантов скопирован в буфер!");
        });
      };

      // Отправка на бэкенд
      const submitBtn = document.getElementById("msavdo-btn-submit");
      const statusMsg = document.getElementById("msavdo-status-msg");

      submitBtn.onclick = () => {
        submitBtn.disabled = true;
        submitBtn.innerHTML = "<span>⏳ Анализ Gemini 3.8 Flash...</span>";
        statusMsg.style.display = "none";

        const payload = {
          raw_html_text: state.rawHtmlText,
          raw_title: document.getElementById("msavdo-inp-title").value.trim() || state.realTitle,
          price_cny: baseCny,
          weight_kg: weightKg,
          original_link: window.location.href,
          images: currentImages.join(","),
          visual_sku_map: visualSkuMap,
          video_url: state.videoUrl,
          use_gemini: true
        };

        chrome.runtime.sendMessage({ action: "importProduct", payload }, (response) => {
          if (chrome.runtime.lastError) {
            statusMsg.style.display = "block";
            statusMsg.style.backgroundColor = "#fef2f2";
            statusMsg.style.color = "#991b1b";
            statusMsg.innerText = "✕ Ошибка расширения: " + chrome.runtime.lastError.message;
            submitBtn.disabled = false;
            submitBtn.innerHTML = "<span>⚡ Повторить</span>";
            return;
          }

          if (response && response.success) {
            statusMsg.style.display = "block";
            statusMsg.style.backgroundColor = "#ecfdf5";
            statusMsg.style.color = "#065f46";
            statusMsg.style.border = "1px solid #a7f3d0";
            statusMsg.innerHTML = `
              ✓ <strong>Товар успешно импортирован через Gemini!</strong><br>
              • Название: <em>${escapeHtml(response.product.title)}</em><br>
              • Категория: <strong>${escapeHtml(response.product.category_name)}</strong><br>
              • Создано вариантов: <strong>${response.product.variants_count} шт.</strong> (с привязкой фото)<br>
              • Статус поставки: <strong>🚚 15–30 дней напрямую с фабрики</strong>
            `;
            submitBtn.innerHTML = "<span>✓ Импортировано!</span>";
            submitBtn.style.backgroundColor = "#16a34a";
            submitBtn.style.color = "#ffffff";
            setTimeout(() => overlay.remove(), 3500);
          } else {
            statusMsg.style.display = "block";
            statusMsg.style.backgroundColor = "#fef2f2";
            statusMsg.style.color = "#991b1b";
            statusMsg.style.border = "1px solid #fecaca";
            statusMsg.innerHTML = `✕ Ошибка: ${escapeHtml(response?.error || 'Сервер не сохранил товар')}`;
            submitBtn.disabled = false;
            submitBtn.innerHTML = "<span>⚡ Повторить</span>";
          }
        });
      };
    }

    renderModal();
    overlay.appendChild(box);
    (document.body || document.documentElement).appendChild(overlay);
  }

  function escapeHtml(str) {
    if (!str) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function triggerCoPilot() {
    const state = gatherProductState();
    openImporterModal(state);
  }

  // ==========================================
  // 8. КНОПКИ ВЫЗОВА НА СТРАНИЦЕ
  // ==========================================
  function injectTriggers() {
    const root = document.body || document.documentElement;
    if (!root) return;

    if (!document.getElementById("msavdo-floating-container")) {
      const container = document.createElement("div");
      container.id = "msavdo-floating-container";
      Object.assign(container.style, {
        position: "fixed",
        bottom: "75px",
        right: "24px",
        zIndex: "2147483646",
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
      });

      const btn = document.createElement("button");
      btn.id = "msavdo-trigger-btn";
      btn.innerHTML = `
        <div style="display:flex; align-items:center; gap:10px;">
          <div style="width:28px; height:28px; background:#FACC15; border-radius:8px; display:flex; align-items:center; justify-content:center; color:#000000; font-weight:900; font-size:15px; box-shadow:0 2px 5px rgba(0,0,0,0.3);">
            M
          </div>
          <div style="display:flex; flex-direction:column; align-items:flex-start; line-height:1.2;">
            <span style="font-weight:900; font-size:13px; color:#FACC15; letter-spacing:-0.3px;">M.SAVDO Co-Pilot</span>
            <span style="font-size:10px; color:#ffffff; font-weight:700;">ИИ-Импорт v5.5</span>
          </div>
        </div>
      `;

      Object.assign(btn.style, {
        padding: "10px 16px",
        backgroundColor: "#000000",
        color: "#ffffff",
        border: "2px solid #FACC15",
        borderRadius: "16px",
        boxShadow: "0 10px 30px rgba(0, 0, 0, 0.6)",
        cursor: "pointer"
      });

      btn.addEventListener("click", triggerCoPilot);
      container.appendChild(btn);
      root.appendChild(container);
    }

    if (!document.getElementById("msavdo-edge-tab")) {
      const edgeTab = document.createElement("div");
      edgeTab.id = "msavdo-edge-tab";
      edgeTab.innerHTML = `
        <span style="font-weight:900; font-size:12px; color:#000000; writing-mode:vertical-rl; text-orientation:mixed; letter-spacing:1px; cursor:pointer;">
          ⚡ M.SAVDO CO-PILOT
        </span>
      `;
      Object.assign(edgeTab.style, {
        position: "fixed",
        top: "42%",
        right: "0",
        backgroundColor: "#FACC15",
        border: "2px solid #000000",
        borderRight: "none",
        borderRadius: "10px 0 0 10px",
        padding: "12px 6px",
        boxShadow: "-3px 4px 15px rgba(0, 0, 0, 0.3)",
        zIndex: "2147483646",
        cursor: "pointer"
      });

      edgeTab.addEventListener("click", triggerCoPilot);
      root.appendChild(edgeTab);
    }
  }

  // Слушатель сообщений от popup.js
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "openImporterModal" || request.action === "triggerImport") {
      triggerCoPilot();
      sendResponse({ success: true, message: "Co-Pilot активирован" });
      return true;
    }

    if (request.action === "gatherProductData") {
      try {
        const state = gatherProductState();
        const payload = {
          raw_html_text: state.rawHtmlText,
          raw_title: state.realTitle,
          price_cny: state.basePriceCny,
          weight_kg: 0.5,
          original_link: window.location.href,
          images: state.images.join(","),
          visual_sku_map: state.visualSkuMap,
          video_url: state.videoUrl,
          use_gemini: true
        };
        sendResponse({ success: true, payload });
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
      return true;
    }
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", injectTriggers);
  } else {
    injectTriggers();
  }

  setInterval(injectTriggers, 2500);

})();
